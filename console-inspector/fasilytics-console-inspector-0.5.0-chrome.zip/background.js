/* Relay: content-script messages -> the devtools panel for that tab. */
const ports = new Map(); // tabId -> panel port

chrome.runtime.onConnect.addListener(function (port) {
  if (port.name !== "fci-devtools") return;
  let tabId = null;
  port.onMessage.addListener(function (msg) {
    if (msg && msg.type === "init") { tabId = msg.tabId; ports.set(tabId, port); }
  });
  port.onDisconnect.addListener(function () {
    if (tabId !== null) ports.delete(tabId);
  });
});

chrome.runtime.onMessage.addListener(function (msg, sender) {
  if (!msg || msg.__FCI__ !== true) return;
  const tabId = sender.tab && sender.tab.id;
  if (tabId == null) return;
  const port = ports.get(tabId);
  if (port) { try { port.postMessage(msg.payload); } catch (e) {} }
});
