/* ISOLATED world — forward page messages to the background relay. */
window.addEventListener("message", function (e) {
  if (e.source !== window) return;
  var d = e.data;
  if (!d || d.__FCI__ !== true) return;
  try { chrome.runtime.sendMessage({ __FCI__: true, payload: d.payload }); } catch (err) {}
});
