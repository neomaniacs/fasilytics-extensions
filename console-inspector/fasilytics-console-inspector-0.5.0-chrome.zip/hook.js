/* MAIN world, document_start — capture uncaught errors + unhandled rejections
   via PASSIVE listeners only. We deliberately do NOT touch console.*, so the
   native console and its stack traces stay 100% clean (no extension frame).
   Trade-off: console-only messages (e.g. Workbox "precaching without revision
   info", the Meta-pixel notice) are not captured. JS errors, rejections, and
   network failures still are. */
(function () {
  if (window.__FCI_HOOKED__) return;
  window.__FCI_HOOKED__ = true;

  function post(o) {
    try { window.postMessage({ __FCI__: true, payload: o }, "*"); } catch (e) {}
  }

  window.addEventListener("error", function (e) {
    // Ignore resource-load failures — the network layer covers those, and they
    // arrive here with no message (pure noise otherwise).
    if (!e.message && e.target && e.target !== window) return;
    post({ kind: "error", level: "error", text: (e.message || "") + "",
      source: (e.filename || "") + (e.lineno ? ":" + e.lineno : ""),
      stack: e.error && e.error.stack ? e.error.stack : "" });
  }, true);

  window.addEventListener("unhandledrejection", function (e) {
    var r = e.reason;
    post({ kind: "rejection", level: "error",
      text: r && r.message ? r.message : String(r),
      stack: r && r.stack ? r.stack : "" });
  });
})();
