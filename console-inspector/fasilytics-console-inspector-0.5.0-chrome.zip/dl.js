/* MAIN world, document_start — log every dataLayer push to the native console
   as one collapsed group, so it can be read without opening any panel.
   Patches .push in place and chains to whatever push was there before, so GTM's
   own override keeps working (lesson from TagSpy: never shadow it). A setter on
   window.dataLayer re-patches when the page reassigns the array. */
(function () {
  if (window.__FCI_DL__) return;
  window.__FCI_DL__ = true;

  var n = 0;

  function snapshot(o) {
    try { return structuredClone(o); } catch (e) { return o; } // functions (eventCallback) can't clone
  }

  function label(o) {
    if (o && typeof o === "object" && !Array.isArray(o) && typeof o.length === "number" && 0 in o) {
      return "gtag " + Array.prototype.slice.call(o, 0, 2).map(String).join(" · "); // gtag('event', 'x')
    }
    if (o && o.event) return String(o.event);
    return "(no event)";
  }

  function log(o) {
    n++;
    var args = o && typeof o === "object" && !Array.isArray(o) && typeof o.length === "number" && 0 in o
      ? Array.prototype.slice.call(o) : o;
    console.groupCollapsed("%cdataLayer%c #" + n + " %c" + label(o),
      "background:#1a73e8;color:#fff;padding:1px 5px;border-radius:3px",
      "color:#888", "font-weight:bold");
    console.log(snapshot(args));
    console.groupEnd();
  }

  function patch(arr) {
    if (!Array.isArray(arr) || arr.__FCI_PATCHED__) return arr;
    for (var i = 0; i < arr.length; i++) log(arr[i]);
    var prev = arr.push;
    arr.push = function () {
      for (var j = 0; j < arguments.length; j++) log(arguments[j]);
      return prev.apply(this, arguments);
    };
    Object.defineProperty(arr, "__FCI_PATCHED__", { value: true });
    return arr;
  }

  var current = patch(window.dataLayer || []);
  try {
    Object.defineProperty(window, "dataLayer", {
      configurable: true,
      get: function () { return current; },
      set: function (v) { current = patch(v); }
    });
  } catch (e) { window.dataLayer = current; }
})();
