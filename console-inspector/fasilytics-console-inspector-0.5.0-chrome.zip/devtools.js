chrome.devtools.panels.create("Console Triage", "", "panel.html");
