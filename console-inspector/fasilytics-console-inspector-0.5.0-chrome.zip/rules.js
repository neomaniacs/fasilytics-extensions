/*
 * FASilytics Console Inspector — rule catalog.
 *
 * Each entry ingested by the panel is normalized to:
 *   { kind: 'network'|'console'|'error'|'rejection',
 *     level: 'error'|'warn'|'info'|'log',
 *     text, url, method, status, errorText, source, stack }
 *
 * Rules are evaluated top to bottom; FIRST match wins.
 * `key(e)` groups identical problems so 50 lines collapse to 1 row + a count.
 * Add a rule here the same way you add a vendor in TagSpy's vendors.js.
 */

const PRIORITY = { critical: 0, high: 1, medium: 2, low: 3 };
const ICON = { critical: "🔴", high: "🟠", medium: "🟡", low: "⚪" };

// Hosts that, when they fail, break tracking/consent rather than page content.
// Broaden this over time — it's the one heuristic that upgrades a net error to critical.
const TRACKING_HOST = /(collect|tags?|tag-|tms|dmp|analytics|y-track|commander|criteo|doubleclick|facebook|tiktok|\bfpc\.)/i;

const RULES = [
  // ---- CRITICAL: tracking pipeline down ------------------------------------
  {
    id: "net-dns-tracking",
    priority: "critical",
    category: "Tracking pipeline",
    test: (e) =>
      e.kind === "network" &&
      /ERR_NAME_NOT_RESOLVED/i.test(e.errorText || "") &&
      TRACKING_HOST.test(e.url || ""),
    title: "First-party collect domain does not resolve (DNS)",
    action:
      "Check the DNS/CNAME on this host — it should point at the vendor edge. Until it resolves, no first-party visitor ID is set and everything downstream fails.",
    key: (e) => "dns:" + host(e.url),
  },
  {
    id: "net-5xx-tracking",
    priority: "critical",
    category: "Tracking pipeline",
    test: (e) =>
      e.kind === "network" && e.status >= 500 && TRACKING_HOST.test(e.url || ""),
    title: "Tracking/DMP endpoint returning 5xx",
    action:
      "Server-side failure on a tracking host. Often downstream of a failed first-party ID call — fix DNS/consent first, then re-test; if it persists, raise it with the vendor.",
    key: (e) => "5xx:" + host(e.url) + ":" + firstPath(e.url),
  },

  // ---- HIGH: broken assets / app crashes -----------------------------------
  {
    id: "net-410",
    priority: "high",
    category: "Assets / caching",
    test: (e) => e.kind === "network" && e.status === 410,
    title: "Asset returns 410 Gone",
    action:
      "A permanently-removed URL is still being requested (often a stale service-worker precache entry). Remove it from the precache manifest / rebuild the hash.",
    key: (e) => "410:" + lastSegment(e.url),
  },
  {
    id: "net-404-script",
    priority: "high",
    category: "Assets / caching",
    test: (e) =>
      e.kind === "network" && e.status === 404 && /\.js(\?|$)/i.test(e.url || ""),
    title: "Script 404",
    action: "A referenced script is missing. Fix the path or remove the reference.",
    key: (e) => "404:" + lastSegment(e.url),
  },
  {
    id: "err-null-prop",
    priority: "high",
    category: "App JS error",
    test: (e) =>
      (e.kind === "error" || e.kind === "console") &&
      /Cannot read propert(y|ies) of null/i.test(e.text || ""),
    title: "TypeError: reading a property of null",
    action:
      "Handler runs before its target element exists (usually a setTimeout/observer race). Null-guard before touching the node.",
    key: (e) => "nullprop:" + (readingWhat(e.text) || e.source || "?"),
  },
  {
    id: "err-undefined-prop",
    priority: "high",
    category: "App JS error",
    test: (e) =>
      (e.kind === "error" || e.kind === "console") &&
      /Cannot read propert(y|ies) of undefined/i.test(e.text || ""),
    title: "TypeError: reading a property of undefined",
    action: "A value is undefined where the code expects an object. Trace where it should have been set.",
    key: (e) => "undefprop:" + (readingWhat(e.text) || e.source || "?"),
  },

  // ---- MEDIUM: swallowed errors & tag-caching risks ------------------------
  {
    id: "rejection",
    priority: "medium",
    category: "Unhandled promise",
    test: (e) => e.kind === "rejection",
    title: "Unhandled promise rejection",
    action:
      "A promise rejected with no .catch(). Often a component awaiting a node/response that isn't there. Add a catch or an existence check.",
    key: (e) => "reject:" + normalizeMsg(e.text),
  },
  {
    id: "workbox-no-revision",
    priority: "medium",
    category: "Assets / caching",
    test: (e) =>
      e.kind === "console" && /precach\w+ URLs without revision info/i.test(e.text || ""),
    title: "Service worker precaching without revision info",
    action:
      "These URLs can't be cache-busted — a stale tagcommander.js / tagging.js may be served after a tag deploy. Add a revision/hash to each precache entry.",
    key: () => "workbox-norev",
  },

  // ---- LOW: browser noise you usually suppress -----------------------------
  {
    id: "violation-passive",
    priority: "low",
    category: "Performance",
    test: (e) => /\[Violation\].*non-passive/i.test(e.text || ""),
    title: "Non-passive scroll listeners",
    action: "Perf hint only. Add { passive: true } to scroll/touch listeners where you don't preventDefault.",
    key: () => "passive",
  },
  {
    id: "aria-hidden-focus",
    priority: "low",
    category: "Accessibility",
    test: (e) => e.kind === "console" && /aria-hidden.*retained focus/i.test(e.text || ""),
    title: "aria-hidden on a focused element",
    action: "Use the `inert` attribute instead of aria-hidden on the container so focus is actually removed.",
    key: () => "aria-hidden",
  },

  // ---- CATCH-ALLS: unknown-but-triaged (this is the 'no AI needed' safety net)
  {
    id: "catch-net-5xx",
    priority: "high",
    category: "Network",
    test: (e) => e.kind === "network" && e.status >= 500,
    title: "Server error (5xx)",
    action: "A request came back 5xx. Open the entry for the host/path; check the server or vendor.",
    key: (e) => "net5xx:" + host(e.url) + ":" + e.status,
  },
  {
    id: "catch-net-failed",
    priority: "medium",
    category: "Network",
    test: (e) => e.kind === "network" && e.status === 0,
    title: "Request failed (blocked / DNS / CORS)",
    action: "The host didn't return a response — DNS failure, network error, CORS, or blocked by an extension. Open the entry for the URL.",
    key: (e) => "netfail:" + host(e.url),
  },
  {
    id: "catch-net-4xx",
    priority: "medium",
    category: "Network",
    test: (e) => e.kind === "network" && e.status >= 400,
    title: "Request error (4xx)",
    action: "A request came back 4xx. Open the entry for the host/path.",
    key: (e) => "net4xx:" + host(e.url) + ":" + e.status,
  },
  {
    id: "catch-uncaught",
    priority: "high",
    category: "Unknown error",
    test: (e) => e.kind === "error",
    title: "Uncaught error (unclassified)",
    action: "No rule matched. Open the detail, or use “Copy for AI” to get a second opinion.",
    key: (e) => "uncaught:" + normalizeMsg(e.text) + ":" + (e.source || ""),
  },
  {
    id: "catch-console-error",
    priority: "medium",
    category: "Unknown error",
    test: (e) => e.kind === "console" && e.level === "error",
    title: "console.error (unclassified)",
    action: "App logged an error. Open the detail, or use “Copy for AI”.",
    key: (e) => "cerr:" + normalizeMsg(e.text),
  },
  {
    id: "catch-console-warn",
    priority: "low",
    category: "Unknown warning",
    test: (e) => e.kind === "console" && e.level === "warn",
    title: "console.warn (unclassified)",
    action: "A warning with no rule. Usually safe; copy for AI if unsure.",
    key: (e) => "cwarn:" + normalizeMsg(e.text),
  },
];

// ---- helpers ---------------------------------------------------------------
function host(u) { try { return new URL(u).host; } catch { return u || "?"; } }
function firstPath(u) { try { return "/" + (new URL(u).pathname.split("/")[1] || ""); } catch { return ""; } }
function lastSegment(u) { try { return new URL(u).pathname.split("/").pop() || u; } catch { return u || "?"; } }
function readingWhat(t) { const m = /reading '([^']+)'/.exec(t || ""); return m && m[1]; }
// Strip volatile bits (numbers, hashes) so near-identical messages group together.
function normalizeMsg(t) { return String(t || "").replace(/\d+/g, "#").slice(0, 80); }

function classify(entry) {
  for (const r of RULES) {
    try {
      if (r.test(entry)) {
        return {
          ruleId: r.id,
          priority: r.priority,
          category: r.category,
          title: r.title,
          action: r.action,
          key: r.key ? r.key(entry) : r.priority + "|" + r.title,
        };
      }
    } catch { /* a broken rule must never break capture */ }
  }
  return null; // truly unrecognized (e.g. plain console.log) → dropped by panel
}
