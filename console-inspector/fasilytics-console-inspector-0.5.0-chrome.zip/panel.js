/* FASilytics Console Inspector — panel logic. */

const store = new Map();  // key -> { info, count, sample }
const listEl = document.getElementById("list");
const summaryEl = document.getElementById("summary");
let hideLow = false;

// --- 1. NETWORK capture (no permission needed, no debugger banner) ----------
// Only ingest failures; 2xx/3xx are noise for a triage tool.
chrome.devtools.network.onRequestFinished.addListener((req) => {
  const res = req.response || {};
  const status = res.status || 0;
  const errorText = res._error || (status === 0 ? "net::ERR (blocked or DNS)" : "");
  if (status !== 0 && status < 400) return;
  ingest({
    kind: "network",
    level: "error",
    url: req.request && req.request.url,
    method: req.request && req.request.method,
    status,
    errorText,
  });
});

// --- 2. CONSOLE capture via a document_start MAIN-world content script -------
// hook.js installs before page scripts run and posts entries through the
// background relay; we receive them here over a long-lived port.
function connect() {
  const port = chrome.runtime.connect({ name: "fci-devtools" });
  port.postMessage({ type: "init", tabId: chrome.devtools.inspectedWindow.tabId });
  port.onMessage.addListener((entry) => ingest(entry));
  port.onDisconnect.addListener(() => setTimeout(connect, 500)); // SW recycled
}
connect();

chrome.devtools.network.onNavigated.addListener((url) => {
  try { cachedHost = new URL(url).host || cachedHost; } catch {} // "Copy for AI" names the new site
  store.clear();
  render(); // hook.js re-runs at document_start on the new page automatically
});

// --- 3. classify + dedupe ---------------------------------------------------
function ingest(entryOrList) {
  const list = Array.isArray(entryOrList) ? entryOrList : [entryOrList];
  let changed = false;
  for (const entry of list) {
    const info = classify(entry);       // from rules.js
    if (!info) continue;                // unrecognized (plain log) → drop
    const bucket = store.get(info.key);
    if (bucket) bucket.count++;
    else store.set(info.key, { info, count: 1, sample: entry });
    changed = true;
  }
  if (changed) render();
}

// --- 4. render --------------------------------------------------------------
document.getElementById("clear").onclick = () => { store.clear(); openKeys.clear(); render(); };
document.getElementById("hideLow").onchange = (e) => { hideLow = e.target.checked; render(); };

function render() {
  let rows = [...store.values()];
  if (hideLow) rows = rows.filter((r) => r.info.priority !== "low");
  rows.sort((a, b) =>
    PRIORITY[a.info.priority] - PRIORITY[b.info.priority] || b.count - a.count);

  const counts = { critical: 0, high: 0, medium: 0, low: 0 };
  for (const r of store.values()) counts[r.info.priority]++;
  summaryEl.innerHTML = Object.keys(counts)
    .map((p) => `<span class="pill ${p}"><i></i>${counts[p]}</span>`).join("");

  listEl.innerHTML = "";
  if (!rows.length) {
    listEl.innerHTML = `<div class="empty">No issues captured yet. Reload the page to capture from load.</div>`;
    return;
  }

  let lastPriority = null;
  for (const r of rows) {
    if (r.info.priority !== lastPriority) {
      lastPriority = r.info.priority;
      const h = document.createElement("div");
      h.className = "group-head";
      h.textContent = r.info.priority;
      listEl.appendChild(h);
    }
    listEl.appendChild(rowEl(r));
  }
}

const openKeys = new Set(); // expanded rows survive re-renders

function rowEl(r) {
  const { info, count, sample } = r;
  const el = document.createElement("div");
  el.className = "row " + info.priority + (openKeys.has(info.key) ? " open" : "");

  // Header: title only — everything else lives behind the "+".
  const head = document.createElement("div");
  head.className = "head";
  head.innerHTML =
    `<span class="plus"></span><span class="dot"></span>` +
    `<span class="title"></span><span class="src"></span><span class="count"></span>`;
  head.querySelector(".title").textContent = info.title;
  head.querySelector(".src").textContent = sourceLabel(sample); // tells twin titles apart
  head.querySelector(".count").textContent = "\u00d7" + count;

  const body = document.createElement("div");
  body.className = "body";
  const inner = document.createElement("div");
  inner.className = "inner";

  const headEl = document.createElement("div");    // the actual error / URL
  headEl.className = "headline";
  headEl.textContent = truncate(headline(sample), 300);

  const meta = document.createElement("div");       // source + category chips
  meta.className = "meta";
  for (const t of [info.priority, sourceLabel(sample), info.category].filter(Boolean)) {
    const c = document.createElement("span");
    c.className = "chip";
    c.textContent = t;
    meta.appendChild(c);
  }

  const action = document.createElement("div");     // what to do
  action.className = "action";
  action.textContent = info.action;

  const detail = document.createElement("div");
  detail.className = "detail";
  detail.appendChild(detailBody(sample, info));

  inner.append(headEl, meta, action, detail);
  body.appendChild(inner);
  el.append(head, body);
  head.onclick = () => {
    if (el.classList.toggle("open")) openKeys.add(info.key);
    else openKeys.delete(info.key);
  };
  return el;
}

// Row headline: the concrete thing (real message, or the request line).
function headline(e) {
  if (e.kind === "network") {
    let loc = e.url || "";
    try { const u = new URL(e.url); loc = u.host + u.pathname; } catch {}
    return `${e.method || "GET"} ${loc} → ${e.status || "failed"}`;
  }
  return e.text || "(no message)";
}
// The "vendor": which file/host the entry came from.
function sourceLabel(e) {
  if (e.kind === "network") { try { return new URL(e.url).host; } catch { return e.url || ""; } }
  return prettySource(e.source);
}
// Full URL:line:col -> file.js:line (full path stays in the detail pane).
function prettySource(s) {
  s = String(s || "");
  if (!s) return "";
  const m = s.match(/([^/]+?):(\d+)(?::\d+)?$/);
  if (m) return m[1] + ":" + m[2];
  try { return new URL(s).pathname.split("/").pop() || s; } catch { return s; }
}
function truncate(s, n) { s = String(s || ""); return s.length > n ? s.slice(0, n) + "…" : s; }

function detailBody(sample, info) {
  const wrap = document.createElement("div");
  const pre = document.createElement("pre");
  pre.textContent = describe(sample);
  const btn = document.createElement("button");
  btn.className = "copy";
  btn.textContent = "📋 Copy for AI";
  btn.onclick = () => {
    navigator.clipboard.writeText(aiPrompt(sample, info)).then(() => {
      btn.textContent = "✓ Copied";
      btn.classList.add("done");
      setTimeout(() => { btn.textContent = "📋 Copy for AI"; btn.classList.remove("done"); }, 1500);
    });
  };
  wrap.append(pre, btn);
  return wrap;
}

// --- 5. formatting ----------------------------------------------------------
function describe(e) {
  const lines = [];
  if (e.kind === "network") {
    lines.push(`Network ${e.method || "GET"} → ${e.status || "failed"}`);
    lines.push(e.url || "");
    if (e.errorText) lines.push(e.errorText);
  } else {
    lines.push(`[${e.level}] ${e.text || ""}`);
    if (e.source) lines.push("at " + e.source);
    if (e.stack) lines.push(e.stack);
  }
  return lines.filter(Boolean).join("\n");
}

// Packaged prompt — context + question, ready to paste into any chatbot.
function aiPrompt(e, info) {
  const site = getHost();
  return [
    `Console issue from ${site} (triaged as ${info.priority.toUpperCase()}: ${info.title}).`,
    ``,
    describe(e),
    ``,
    `What is the likely root cause, and how do I fix it?`,
  ].join("\n");
}

let cachedHost = "the page";
function getHost() { return cachedHost; }
chrome.devtools.inspectedWindow.eval("location.host", (h) => { if (h) cachedHost = h; });

render();
