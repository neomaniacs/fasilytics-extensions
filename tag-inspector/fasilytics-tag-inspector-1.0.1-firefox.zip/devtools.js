chrome.devtools.panels.create(
  "TagSpy",
  "icons/icon16.png",
  "panel.html",
  function(panel) {
    panel.onShown.addListener(function(win) {});
    panel.onHidden.addListener(function() {});
  }
);
