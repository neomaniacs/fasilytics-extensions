// TagSpy — Background Service Worker
// Manages communication between content scripts and DevTools panels

const tabConnections = {};
const tabEvents = {};
const tabLoading = {};

// Events buffered before the panel opens are mirrored in storage.session:
// Chrome stops the service worker after ~30 s idle and wipes globals.
const bufKey = (tid) => 'buf:' + tid;

function loadBuffer(tid) {
  if (!tabLoading[tid]) {
    tabLoading[tid] = tabEvents[tid]
      ? Promise.resolve(tabEvents[tid])
      : chrome.storage.session.get(bufKey(tid))
          .then(r => (tabEvents[tid] = tabEvents[tid] || r[bufKey(tid)] || []))
          .catch(() => (tabEvents[tid] = tabEvents[tid] || []));
  }
  return tabLoading[tid];
}

function clearBuffer(tid) {
  delete tabEvents[tid];
  delete tabLoading[tid];
  chrome.storage.session.remove(bufKey(tid)).catch(() => {});
}

// Runs in page MAIN world via chrome.scripting.executeScript.
// Not a DOM-injected <script> tag -> not subject to page's CSP script-src.
function tagspyInjectorMain(WATCH_VARS) {
  if (window.__tagspyInjected) return;
  window.__tagspyInjected = true;

  // Strip non-cloneable values (functions, DOM nodes, symbols, circular refs)
  // before postMessage — raw structured-clone throws DataCloneError otherwise
  // (seen with gtag/GCM proxy pushes carrying live refs).
  function safeClone(val) {
    try {
      return JSON.parse(JSON.stringify(val, (key, v) => {
        if (typeof v === 'function' || typeof v === 'symbol') return undefined;
        if (v instanceof Node) return '[DOMNode]';
        if (v instanceof Window) return '[Window]';
        return v;
      }));
    } catch (e) {
      return { __tagspyUncloneable: true, note: String(e && e.message || e) };
    }
  }

  const send = (data) => {
    try {
      window.postMessage({ __tagspy: true, ...data, data: safeClone(data.data) }, '*');
    } catch (e) { /* swallow, never break host page */ }
  };

  function interceptArray(varName) {
    const arr = Array.isArray(window[varName]) ? window[varName] : (window[varName] = []);
    // Already hooked (e.g. re-run from the poll below) — don't wrap our own
    // hook again, that's a second source of infinite recursion.
    if (arr.push && arr.push.__tagspyHooked) return;

    arr.forEach(item => {
      if (item && typeof item === 'object') send({ source: 'datalayer', varName, data: item, ts: Date.now() });
    });

    // Patch .push in place (no Proxy, no object-identity swap) so
    // window[varName] stays the exact array GTM/gtag already hold a
    // reference to. Chain to a permanently-fixed Array.prototype.push, never
    // to "whatever .push currently is": GTM's own dataLayer.push override
    // typically does `var old = dataLayer.push; dataLayer.push = fn` and
    // calls `old` at the end of `fn`. If our hook re-read the *current*
    // .push instead of this fixed native reference, `old` (our hook) would
    // call back into `fn` (now installed) every time it runs, and `fn` would
    // call `old` again -> infinite mutual recursion (this is what produced
    // the endless dataLayer.push() loop). Chaining to a frozen native push
    // instead means our hook is always a safe, terminating leaf call, while
    // GTM's own override function itself still runs normally on every future
    // push (so its trigger evaluation / tag firing keeps working).
    const nativePush = Array.prototype.push;
    const hookedPush = function(...args) {
      args.forEach(item => {
        if (item && typeof item === 'object') send({ source: 'datalayer', varName, data: item, ts: Date.now() });
      });
      return nativePush.apply(arr, args);
    };
    hookedPush.__tagspyHooked = true;
    arr.push = hookedPush;
  }

  function interceptObject(varName) {
    let current = window[varName];
    if (current && typeof current === 'object') send({ source: 'datalayer', varName, data: { ...current }, ts: Date.now() });
    try {
      Object.defineProperty(window, varName, {
        configurable: true,
        get() { return current; },
        set(val) {
          current = val;
          if (val && typeof val === 'object') send({ source: 'datalayer', varName, data: { ...val }, ts: Date.now() });
        }
      });
    } catch(e) {}
  }

  function intercept(varName) {
    const val = window[varName];
    if (Array.isArray(val) || varName === 'dataLayer') {
      interceptArray(varName);
    } else {
      interceptObject(varName);
    }
  }

  WATCH_VARS.forEach(varName => {
    intercept(varName);
    let attempts = 0;
    const iv = setInterval(() => {
      if (window[varName] !== undefined || ++attempts > 25) clearInterval(iv);
      else intercept(varName);
    }, 200);
  });
}

chrome.runtime.onConnect.addListener(function(port) {
  if (port.name !== 'tagspy-panel') return;

  port.onMessage.addListener(function(msg) {
    if (msg.type === 'PANEL_INIT') {
      const tid = msg.tabId;
      tabConnections[tid] = port;
      loadBuffer(tid).then(buf => {
        buf.forEach(ev => port.postMessage(ev));
        clearBuffer(tid);
      });
    }
  });

  port.onDisconnect.addListener(function() {
    for (const [tid, p] of Object.entries(tabConnections)) {
      if (p === port) { delete tabConnections[tid]; break; }
    }
  });
});

chrome.runtime.onMessage.addListener(function(msg, sender) {
  if (!sender.tab) return;
  const tabId = sender.tab.id;

  if (msg.type === 'TAGSPY_INJECT') {
    chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      world: 'MAIN',
      injectImmediately: true,
      func: tagspyInjectorMain,
      args: [msg.vars]
    }).catch(() => {});
    return;
  }

  if (msg.type === 'TAGSPY_EVENT') {
    const event = { ...msg.event, tabId };
    if (tabConnections[tabId]) {
      tabConnections[tabId].postMessage({ type: 'NEW_EVENT', event });
    } else {
      loadBuffer(tabId).then(buf => {
        // Buffer cleared meanwhile (reload / panel flush): don't resurrect it.
        if (tabEvents[tabId] !== buf || buf.length >= 500) return;
        buf.push({ type: 'NEW_EVENT', event });
        chrome.storage.session.set({ [bufKey(tabId)]: buf }).catch(() => {});
      });
    }
  }

  if (msg.type === 'TAGSPY_PAGE_RELOAD') {
    if (tabConnections[tabId]) tabConnections[tabId].postMessage({ type: 'PAGE_RELOAD' });
  }
});

chrome.tabs.onUpdated.addListener(function(tabId, changeInfo) {
  if (changeInfo.status === 'loading') {
    if (tabConnections[tabId]) tabConnections[tabId].postMessage({ type: 'PAGE_RELOAD' });
    clearBuffer(tabId);
  }
});

chrome.tabs.onRemoved.addListener(clearBuffer);
