// TagSpy — Default vendor definitions

const TAGSPY_DEFAULT_VENDORS = [
  { id: 'gtm', name: 'Google Tag Manager', editor: 'Google', shortName: 'GTM', color: '#4285F4', patterns: ['googletagmanager\.com/gtm\.js', 'googletagmanager\.com/ns\.html'], type: 'tms', enabled: true, builtin: true },
  // Google tag (gtag.js), Google's unified tag -- not GTM, even though it is
  // served from googletagmanager.com. Both GTM and gtag.js push to the same
  // window.dataLayer, so pushes there go to the neutral Google dataLayer
  // entry below instead of being credited to either tool.
  { id: 'gtag', name: 'GTag', editor: 'Google', shortName: 'GTAG', color: '#1A73E8', patterns: ['googletagmanager\.com/gtag/js'], type: 'tms', enabled: true, builtin: true },
  { id: 'google_datalayer', name: 'dataLayer', editor: 'Google', shortName: 'GDL', color: '#7B1FA2', patterns: [], datalayer: 'dataLayer', type: 'datalayer', enabled: true, builtin: true },
  { id: 'gpt', name: 'Google Publisher Tag', editor: 'Google', shortName: 'GPT', color: '#669DF6', patterns: ['securepubads\.g\.doubleclick\.net', 'pubads\.g\.doubleclick\.net', 'googlesyndication\.com/tag/js/gpt\.js', 'googlesyndication\.com/pagead/managed', 'googlesyndication\.com/pagead/gpt', 'googletagservices\.com/tag/js/gpt\.js', 'safeframe\.googlesyndication\.com'], type: 'ads', enabled: true, builtin: true },
  { id: 'ga4', name: 'Google Analytics 4', editor: 'Google', shortName: 'GA4', color: '#E37400', patterns: ['google-analytics\.com/g/collect', 'analytics\.google\.com/g/collect', 'google-analytics\.com/collect'], type: 'analytics', enabled: true, builtin: true },
  { id: 'floodlight', name: 'Google Floodlight', editor: 'Google', shortName: 'FL', color: '#34A853', patterns: ['ad\.doubleclick\.net/activity', 'fls\.doubleclick\.net', 'googleadservices\.com/pagead'], type: 'ads', enabled: true, builtin: true },
  { id: 'google_ads', name: 'Google Ads (Conversion Tracking)', editor: 'Google', shortName: 'GADS', color: '#4285F4', patterns: ['googleads\.g\.doubleclick\.net', 'googleadservices\.com/pagead/conversion', 'googleadservices\.com/pagead/1p-conversion'], type: 'ads', enabled: true, builtin: true },
  { id: 'meta', name: 'Meta Pixel', editor: 'Meta', shortName: 'META', color: '#1877F2', patterns: ['facebook\.com/tr', 'connect\.facebook\.net'], type: 'ads', enabled: true, builtin: true },
  { id: 'tiktok', name: 'TikTok Pixel', editor: 'TikTok', shortName: 'TTOK', color: '#FE2C55', patterns: ['analytics\.tiktok\.com', 'business-api\.tiktok\.com'], type: 'ads', enabled: true, builtin: true },
  { id: 'pinterest', name: 'Pinterest Tag', editor: 'Pinterest', shortName: 'PIN', color: '#E60023', patterns: ['ct\.pinterest\.com'], type: 'ads', enabled: true, builtin: true },
  { id: 'linkedin', name: 'LinkedIn Insight', editor: 'LinkedIn', shortName: 'LI', color: '#0A66C2', patterns: ['px\.ads\.linkedin\.com', 'snap\.licdn\.com'], type: 'ads', enabled: true, builtin: true },
  { id: 'criteo', name: 'Criteo', editor: 'Criteo', shortName: 'CRTO', color: '#F57C00', patterns: ['dis\.criteo\.com', 'static\.criteo\.net', 'gum\.criteo\.com', 'sslwidget\.criteo\.com'], type: 'ads', enabled: true, builtin: true },
  { id: 'snapchat', name: 'Snapchat Pixel', editor: 'Snapchat', shortName: 'SNAP', color: '#1E1E1E', patterns: ['tr\.snapchat\.com', 'sc-static\.net'], type: 'ads', enabled: true, builtin: true },
  { id: 'twitter', name: 'X / Twitter Pixel', editor: 'X', shortName: 'X', color: '#000000', patterns: ['analytics\.twitter\.com', 'ads-twitter\.com'], type: 'ads', enabled: true, builtin: true },
  { id: 'commanders', name: 'Commanders Act', editor: 'Commanders Act', shortName: 'CA', color: '#E31B23', patterns: ['tagcommander\.com', 'commander1\.com', 'commanders1\.com', 'cmdrs\.net', 'manager\.tagcommander\.com', '/events\\?(?:[^#]*&)?tc_s=\\d'], datalayer: 'tc_vars', type: 'tms', enabled: true, builtin: true },
  { id: 'adobe_launch', name: 'Adobe Launch / DTM', editor: 'Adobe', shortName: 'DTM', color: '#FF0000', patterns: ['adobedtm\.com', 'assets\.adobedtm\.com'], datalayer: 'digitalData', type: 'tms', enabled: true, builtin: true },
  { id: 'piano', name: 'Piano Analytics (AT Internet)', editor: 'Piano', shortName: 'PIANO', color: '#001F5C', patterns: ['atinternet\.com', 'piano\.io/tag', 'tag\.aticdn\.net'], datalayer: 'ATInternet', type: 'analytics', enabled: true, builtin: true },
  { id: 'hotjar', name: 'Hotjar', editor: 'Hotjar', shortName: 'HJ', color: '#FD3A5C', patterns: ['hotjar\.com/api', 'script\.hotjar\.com'], type: 'analytics', enabled: true, builtin: true },
  { id: 'mpulse', name: 'Akamai mPulse', editor: 'Akamai', shortName: 'MPULSE', color: '#0091DA', patterns: ['go-mpulse\.net'], type: 'analytics', enabled: true, builtin: true },
  { id: 'zendesk', name: 'Zendesk Widget', editor: 'Zendesk', shortName: 'ZEN', color: '#03363D', patterns: ['zdassets\.com', 'zendesk\.com/embeddable'], type: 'other', enabled: true, builtin: true },
  { id: 'bazaarvoice', name: 'Bazaarvoice', editor: 'Bazaarvoice', shortName: 'BV', color: '#F26522', patterns: ['bazaarvoice\.com'], type: 'other', enabled: true, builtin: true },
  { id: 'abtasty', name: 'AB Tasty', editor: 'AB Tasty', shortName: 'ABT', color: '#00C4B3', patterns: ['abtasty\.com'], type: 'other', enabled: true, builtin: true },
  { id: 'salesforce_cquotient', name: 'Salesforce Einstein (CQuotient)', editor: 'Salesforce', shortName: 'SFCC', color: '#00A1E0', patterns: ['cquotient\.com'], type: 'other', enabled: true, builtin: true },
  // Wunderkind (ex-BounceX). Loader = tag.wknd.ai/{websiteId}/i.js (legacy
  // host tag.bounceexchange.com, same path); tag modules + creatives on
  // assets.bounceexchange.com; tracking beacons on events.bouncex.net/
  // track.gif/{event}. Hosts confirmed from vendor CSP list + DuckDuckGo
  // tracker-radar resource samples (2026-09-03).
  { id: 'wunderkind', name: 'Wunderkind', editor: 'Wunderkind', shortName: 'WKND', color: '#7B2CBF', patterns: ['\\bwknd\\.ai', '\\bbounceexchange\\.com', '\\bbouncex\\.net'], type: 'other', enabled: true, builtin: true },
  // Batch (web push / CRM). SDK bootstrap + modules on via.batch.com; web
  // services on ws.batch.com/web/{sdkVer}/{ev|atc|ats}/{apiKey};
  // safari-ws.batch.com/{apiKey}/...; icons.batch.com for creatives.
  // Hosts confirmed from doc.batch.com CSP guide + SDK 4.4.0 source.
  { id: 'batch', name: 'Batch', editor: 'Batch', shortName: 'BATCH', color: '#1F6FEB', patterns: ['\\bbatch\\.com'], type: 'other', enabled: true, builtin: true },
  // Imagino (CRM / marketing automation). Loader =
  // {tenant}.tag.imagino.com/public/api.js?apiKey=... — host taken from a
  // live tag (2026-10-05); only the loader has been observed so far.
  { id: 'imagino', name: 'Imagino', editor: 'Imagino', shortName: 'IMG', color: '#E4572E', patterns: ['\\bimagino\\.com'], type: 'other', enabled: true, builtin: true }
];

function getVendorForUrl(url, vendorList) {
  for (const vendor of vendorList) {
    if (!vendor.enabled) continue;
    for (const pat of vendor.patterns) {
      try {
        if (new RegExp(pat, 'i').test(url)) {
          // Real Google Analytics collection endpoints always have "collect"
          // or "metrics" as a PATH SEGMENT, regardless of hostname. Enforced
          // globally for ga4 so a broad custom/extra pattern (e.g. a bare
          // hostname added to catch a proxied GA4 endpoint) can't swallow
          // every other same-origin request on that domain -- if this
          // pattern matched but the URL isn't an actual collect/metrics hit,
          // skip it and keep trying this vendor's other patterns. Anchored
          // to slash boundaries (not a bare substring test) so a filename
          // that merely contains the word -- e.g. "icon-bag-click-and-
          // collect.svg", the French retail term for in-store pickup --
          // doesn't false-positive.
          if (vendor.id === 'ga4') {
            if (!/\/(?:collect|metrics)(?:[/?]|$)/i.test(url)) continue;
            // Google's unified "Google tag" gateway sends GA4, Google Ads
            // conversions, and Floodlight hits through the SAME g/collect
            // endpoint -- they only differ by the tid param's prefix
            // (G-/AW-/DC-), not by hostname. Reclassify using the actual tid.
            // Some sub-services on that same gateway (e.g. the Floodlight
            // counter/sales hit at /metrics/td) identify themselves via `id=`
            // instead of `tid=` -- check tid first (primary format), fall
            // back to id only when tid is absent.
            const tidMatch = url.match(/[?&]tid=([^&;]+)/) || url.match(/[?&]id=([^&;]+)/);
            const tid = tidMatch ? decodeURIComponent(tidMatch[1]) : '';
            if (/^AW-/i.test(tid)) return vendorList.find(v => v.id === 'google_ads' && v.enabled) || vendor;
            if (/^DC-/i.test(tid)) return vendorList.find(v => v.id === 'floodlight' && v.enabled) || vendor;
            // Some server-side/first-party proxies (e.g. a client's own
            // gtag gateway) forward Ads/Floodlight hits with neither a
            // tid= nor id= param at all -- confirmed live on
            // metrics.example.com/metrics/d/pagead/form-data/... and
            // .../metrics/d/ccm/form-data/..., which stayed misclassified
            // as GA4 with no signal to reclassify them. Two more signals,
            // most authoritative first: `hn=` is Google's own hint of the
            // real destination hostname this hit was meant for (present on
            // the /metrics/as/... conversion hits); when absent, fall back
            // to the literal /pagead/ or /ccm/ path segment Google's
            // gateway uses to route Ads vs Floodlight (Campaign Manager)
            // traffic.
            const hnMatch = url.match(/[?&]hn=([^&;]+)/);
            const hn = hnMatch ? decodeURIComponent(hnMatch[1]) : '';
            if (/googleadservices\.com|googleads\.g\.doubleclick\.net/i.test(hn)) return vendorList.find(v => v.id === 'google_ads' && v.enabled) || vendor;
            if (/doubleclick\.net/i.test(hn)) return vendorList.find(v => v.id === 'floodlight' && v.enabled) || vendor;
            if (/\/pagead\//i.test(url)) return vendorList.find(v => v.id === 'google_ads' && v.enabled) || vendor;
            if (/\/ccm\//i.test(url)) return vendorList.find(v => v.id === 'floodlight' && v.enabled) || vendor;
          }
          return vendor;
        }
      } catch(e) {}
    }
  }
  return null;
}

function parseUrlParams(url) {
  const params = {};
  try {
    const qmark = url.indexOf('?');
    const beforeQuery = qmark !== -1 ? url.substring(0, qmark) : url;
    if (beforeQuery.includes(';')) {
      beforeQuery.split(';').slice(1).forEach(p => {
        const [k, ...v] = p.split('=');
        if (k) params[decodeURIComponent(k)] = v.length ? decodeURIComponent(v.join('=')) : '';
      });
    }
    if (qmark !== -1) {
      url.substring(qmark + 1).split('&').forEach(pair => {
        const [k, ...v] = pair.split('=');
        if (k) { try { params[decodeURIComponent(k)] = decodeURIComponent(v.join('=') || ''); } catch(e) { params[k] = v.join('=') || ''; } }
      });
    }
  } catch(e) {}
  return params;
}

function parsePostBody(body) {
  if (!body) return null;
  try { return JSON.parse(body); } catch(e) {}
  // GA4 (Measurement Protocol) batches multiple hits into one POST body when
  // they fire close together -- one flat query-string per hit, separated by
  // \r\n. A plain single-hit body is just one line and falls through this
  // same per-line parser unchanged, so the return type only becomes an array
  // when a real batch is present.
  const hits = body.split(/\r\n|\n/).map(line => {
    const params = {};
    line.split('&').forEach(pair => {
      const [k, ...v] = pair.split('=');
      if (k) { try { params[decodeURIComponent(k)] = decodeURIComponent(v.join('=') || ''); } catch(e) { params[k] = v.join('=') || ''; } }
    });
    return params;
  }).filter(p => Object.keys(p).length);
  if (!hits.length) return null;
  return hits.length > 1 ? hits : hits[0];
}
