// TagSpy — Content Script
// Intercepts dataLayer pushes and custom datalayer variables

(function() {
  'use strict';

  // ext reload/update while old content script alive in page (SPA nav, no
  // full reload) -> chrome.runtime ctx dies. Even reading chrome.runtime.id
  // can throw post-invalidation -> wrap that check itself too.
  function isCtxAlive() {
    try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; }
  }

  function safeSend(msg) {
    if (!isCtxAlive()) return;
    try { chrome.runtime.sendMessage(msg); } catch (e) { /* ctx died mid-call, ignore */ }
  }

  let watchedVars = ['dataLayer', 'tc_vars', 'digitalData', 'ATInternet', 'utag_data'];

  if (isCtxAlive()) {
    try {
      chrome.storage.local.get(['tagspy_vendors', 'tagspy_custom_vendors'], function(result) {
        if (!isCtxAlive()) return;
        const all = [
          ...(result.tagspy_vendors || []),
          ...(result.tagspy_custom_vendors || [])
        ];
        const dlVars = all.filter(v => v.datalayer && v.enabled).map(v => v.datalayer);
        watchedVars = [...new Set([...watchedVars, ...dlVars])];
        // Ask background to inject interceptor via chrome.scripting (world: MAIN).
        // NOTE: no more <script> textContent injection -> avoids page CSP script-src block.
        safeSend({ type: 'TAGSPY_INJECT', vars: watchedVars });
      });
    } catch (e) { /* ctx died before callback fired */ }
  }

  window.addEventListener('message', function(e) {
    if (!e.data || !e.data.__tagspy) return;
    safeSend({
      type: 'TAGSPY_EVENT',
      event: { source: e.data.source, varName: e.data.varName, data: e.data.data, ts: e.data.ts || Date.now(), url: window.location.href }
    });
  });

  window.addEventListener('beforeunload', function() {
    safeSend({ type: 'TAGSPY_PAGE_RELOAD' });
  });
})();
