// TagSpy - Panel JS
// Handles: network events, dataLayer events, rendering, filtering, detail view

(function() {
  'use strict';

  let events = [];
  let eventIdCounter = 0;
  let selectedId = null;
  let checkedIds = new Set();
  let prettyDL = new Set();
  let recording = true;
  let vendors = [];
  let activeDetailTab = 'params';
  let firstEventTs = null;
  // Right-click row filters. Each: { column, value, mode }. column is one of
  // eventType/vendor/method/status/eventName/pixelId; mode is 'show' (allow-
  // list -- a row passes only if it matches at least one 'show' filter, when
  // any exist) or 'hide' (block-list -- a row is dropped if it matches ANY
  // 'hide' filter). The two groups combine with AND, so e.g. "Show: Vendor
  // GA4" + "Hide: Type Script Load" isolates GA4 rows minus its script
  // loads. Superseded the old single "Hide Scripts" button AND the All
  // Types dropdown + free-text search (both removed) -- right-click a row's
  // Type/Event/Method/Status/Pixel ID gives more precise filtering than
  // either did.
  let rowFilters = [];
  let ctxMenuMode = 'hide';
  let ctxMenuEv = null;

  // Column widths for the resizable columns. check/num/time stay fixed.
  // Event now has its own resizable width too (was always the flexible
  // remainder before, which meant it could get very wide and truncate
  // Pixel ID next to it with no way to shrink it). A hidden trailing
  // minmax(0,1fr) spacer column (not in colWidths, has no header/handle)
  // now absorbs any leftover width so the table still fills the container.
  // Persisted to chrome.storage.local so a manual resize survives closing/
  // reopening the DevTools panel.
  const COL_DEFAULTS = { check: 18, num: 36, vendor: 80, type: 90, event: 240, method: 52, status: 48, pixelid: 90, time: 64 };
  const COL_MIN = { vendor: 40, type: 40, event: 60, method: 36, status: 36, pixelid: 40 };
  let colWidths = { ...COL_DEFAULTS };

  function applyColLayout() {
    const c = colWidths;
    const str = c.check + 'px ' + c.num + 'px ' + c.vendor + 'px ' + c.type + 'px ' + c.event + 'px ' +
      c.method + 'px ' + c.status + 'px ' + c.pixelid + 'px ' + c.time + 'px minmax(0,1fr)';
    document.getElementById('root').style.setProperty('--col-layout', str);
  }

  function loadColWidths() {
    try {
      chrome.storage.local.get(['tagspy_col_widths'], function(r) {
        if (r && r.tagspy_col_widths) colWidths = { ...COL_DEFAULTS, ...r.tagspy_col_widths };
        applyColLayout();
      });
    } catch (e) { applyColLayout(); }
  }

  function saveColWidths() {
    try { chrome.storage.local.set({ tagspy_col_widths: colWidths }); } catch (e) {}
  }

  loadColWidths();

  document.querySelectorAll('.col-drag').forEach(function(handle) {
    const col = handle.dataset.colResize;
    let dragging = false, startX = 0, startWidth = 0;
    handle.addEventListener('mousedown', function(e) {
      dragging = true;
      startX = e.clientX;
      startWidth = colWidths[col];
      handle.classList.add('dragging');
      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none';
      e.preventDefault();
    });
    document.addEventListener('mousemove', function(e) {
      if (!dragging) return;
      const min = COL_MIN[col] || 24;
      colWidths[col] = Math.max(min, startWidth + (e.clientX - startX));
      applyColLayout();
    });
    document.addEventListener('mouseup', function() {
      if (!dragging) return;
      dragging = false;
      handle.classList.remove('dragging');
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      saveColWidths();
    });
  });

  loadVendors().then(() => {
    updateVendorFilterOptions();
    startNetworkListener();
    connectToBackground();
    updateLastPageUrl();
  });

  function loadVendors() {
    return new Promise(resolve => {
      chrome.storage.local.get(['tagspy_vendors', 'tagspy_custom_vendors', 'tagspy_extra_patterns'], function(result) {
        const builtinState = result.tagspy_vendors || {};
        const customs = result.tagspy_custom_vendors || [];
        const extra = result.tagspy_extra_patterns || {};
        vendors = TAGSPY_DEFAULT_VENDORS.map(v => ({
          ...v,
          enabled: builtinState[v.id] !== undefined ? builtinState[v.id] : v.enabled,
          patterns: extra[v.id] && extra[v.id].length ? [...v.patterns, ...extra[v.id]] : v.patterns
        }));
        customs.forEach(cv => {
          const patterns = extra[cv.id] && extra[cv.id].length ? [...(cv.patterns || []), ...extra[cv.id]] : cv.patterns;
          vendors.push({ ...cv, builtin: false, patterns });
        });
        resolve();
      });
    });
  }

  // Best-effort URL of the page currently attached to the DevTools panel,
  // persisted so the Options page's "Use current tab URL" button can suggest
  // it -- Options opens in its own tab, so chrome.tabs.query from there would
  // just see the Options page itself, not the site being inspected.
  function updateLastPageUrl() {
    try {
      chrome.devtools.inspectedWindow.eval('location.href', function(result, isException) {
        if (!isException && typeof result === 'string' && result) {
          chrome.storage.local.set({ tagspy_last_page_url: result });
        }
      });
    } catch (e) {}
  }

  // Ext reload while devtools panel stays open -> panel's own chrome.runtime
  // dies too (not just content-script side). connect()/postMessage then
  // throw "Extension context invalidated". Guard + drop retry loop (id dead
  // forever, no auto-heal possible -- user must close/reopen devtools).
  function isCtxAlive() {
    try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; }
  }

  function connectToBackground() {
    if (!isCtxAlive()) return;
    let port;
    try {
      port = chrome.runtime.connect({ name: 'tagspy-panel' });
      port.postMessage({ type: 'PANEL_INIT', tabId: chrome.devtools.inspectedWindow.tabId });
    } catch (e) { return; }
    port.onMessage.addListener(function(msg) {
      if (msg.type === 'NEW_EVENT') handleDLEvent(msg.event);
      if (msg.type === 'PAGE_RELOAD') handlePageReload();
    });
    port.onDisconnect.addListener(function() {
      if (isCtxAlive()) setTimeout(connectToBackground, 500);
    });
  }

  function handleDLEvent(ev) {
    if (!recording) return;
    const varName = ev.varName || 'dataLayer';
    const data = ev.data;
    if (!data || typeof data !== 'object') return;
    const matchedVendor = vendors.find(v => v.datalayer === varName && v.enabled) || {
      id: 'datalayer', name: 'DataLayer', shortName: 'DL', color: '#7B1FA2', type: 'datalayer'
    };
    const eventName = data.event || data.eventName || data.event_name || '(push)';
    addEvent({ source: 'datalayer', vendor: matchedVendor, eventName: String(eventName), eventType: 'DL Push', varName, data, url: ev.url, ts: ev.ts || Date.now(), method: '', status: null });
  }

  function handlePageReload() {
    updateLastPageUrl();
    chrome.storage.local.get(['tagspy_clear_on_nav'], function(r) {
      if (r.tagspy_clear_on_nav) clearEvents();
    });
  }

  // HAR postData (req.request.postData.text) = actual REQUEST payload sent to server.
  // req.getContent() = RESPONSE body -- captured separately, both shown in detail pane.
  // Response fetch is async, arrives after the row already renders -> patch in
  // once ready and re-render detail pane if that event is still selected.
  const MAX_RESPONSE_CHARS = 20000;

  // Headers as {name,value} array (raw HAR shape) -> plain object, drops noise
  // like cookie/user-agent verbosity isn't filtered here on purpose: the Copy
  // feature is meant to be a lighter *subset of fields* than a full HAR export,
  // not a redaction tool -- headers are already small compared to full HAR.
  function headersToObj(list) {
    if (!list || !list.length) return {};
    const obj = {};
    list.forEach(h => { obj[h.name] = h.value; });
    return obj;
  }

  // Best-effort pixel/container ID extraction per vendor. Some vendors put
  // the ID in the URL, others in the JSON POST body -- checking both,
  // preferring the payload when present since it's the more reliable
  // source (URL query params can be truncated/rewritten by proxies).
  //
  // Confirmed live this session: ga4 (tid, URL), floodlight (src, URL),
  // commanders (tc_s, URL), gtm (id, URL), tiktok (context.pixel.code /
  // context.pixel.codes, JSON BODY -- TikTok's /api/v2/pixel endpoint never
  // puts the pixel code in the URL, so a URL-only regex always returned
  // null here; fixed to read the payload instead). The "codes" (plural)
  // fallback covers TikTok's deduplicated "act"/Metadata call, which is
  // shared across multiple pixels on the page and lists them pipe-joined
  // instead of sending one call per pixel.
  //
  // The rest (meta/pinterest/linkedin/snapchat/twitter/criteo/adobe_launch/
  // gpt) are still best-guess URL-param patterns and have NOT been verified
  // against live traffic -- flag any that come back blank/wrong.
  function extractPixelId(vendor, url, postParams) {
    try {
      let m;
      switch (vendor.id) {
        case 'ga4':
          m = url.match(/[?&]tid=([^&;]+)/); return m ? decodeURIComponent(m[1]) : null;
        case 'floodlight':
          m = url.match(/;src=(\d+)/); if (m) return m[1];
          m = url.match(/[?&]tid=([^&;]+)/) || url.match(/[?&]id=([^&;]+)/);
          return m ? decodeURIComponent(m[1]) : null;
        case 'google_ads':
          m = url.match(/[?&]tid=([^&;]+)/) || url.match(/[?&]id=([^&;]+)/);
          return m ? decodeURIComponent(m[1]) : null;
        case 'commanders':
          m = url.match(/[?&]tc_s=(\d+)/); return m ? m[1] : null;
        case 'gtm':
          m = url.match(/[?&]id=(GTM-[A-Z0-9]+)/i); return m ? m[1].toUpperCase() : null;
        case 'meta':
          m = url.match(/[?&]id=(\d+)/); return m ? m[1] : null;
        case 'tiktok': {
          const pixel = postParams && postParams.context && postParams.context.pixel;
          if (pixel && pixel.code) return pixel.code;
          if (pixel && pixel.codes) return pixel.codes;
          m = url.match(/[?&](?:sdkid|pixel_code|pixelCode)=([^&]+)/i);
          return m ? decodeURIComponent(m[1]) : null;
        }
        case 'pinterest':
          m = url.match(/[?&]tid=(\d+)/); return m ? m[1] : null;
        case 'linkedin':
          m = url.match(/[?&]pid=(\d+)/); return m ? m[1] : null;
        case 'snapchat':
          m = url.match(/[?&]pixel(?:_id)?=([^&]+)/i); return m ? decodeURIComponent(m[1]) : null;
        case 'twitter':
          m = url.match(/[?&]txn_id=([^&]+)/i); return m ? decodeURIComponent(m[1]) : null;
        case 'criteo':
          m = url.match(/[?&]a=(\d+)/); return m ? m[1] : null;
        case 'adobe_launch':
          m = url.match(/\/([a-f0-9]{32})\//i); return m ? m[1] : null;
        case 'gpt':
          m = url.match(/[?&]iu=([^&]+)/); return m ? decodeURIComponent(m[1]) : null;
        case 'wunderkind':
          // Website ID is the numeric path segment of the loader
          // (tag.wknd.ai/{id}/i.js) and of the per-site config bundle
          // (assets.bounceexchange.com/cache/{id}/website-*.js); creatives
          // sit under /assets/uploads/clients/{id}/. The events.bouncex.net
          // track.gif beacons carry no ID in their path (unverified live).
          m = url.match(/\/(\d+)\/i\.js/) || url.match(/\/cache\/(\d+)\//) || url.match(/\/clients\/(\d+)\//);
          return m ? m[1] : null;
        case 'batch':
          // API key = 32-char uppercase alphanumeric path segment: ws.batch.com/web/{ver}/{ev|atc|ats}/
          // {apiKey} and safari-ws.batch.com/{apiKey}/... (SDK 4.4.0 source).
          // via.batch.com script loads carry no key.
          m = url.match(/\/([A-Z0-9]{24,40})(?:[/?#]|$)/); return m ? m[1] : null;
        default:
          return null;
      }
    } catch (e) { return null; }
  }

  function startNetworkListener() {
    chrome.devtools.network.onRequestFinished.addListener(function(req) {
      if (!recording) return;
      const url = req.request.url;
      if (!url || url.startsWith('chrome-extension://') || url.startsWith('moz-extension://')) return;
      const vendor = getVendorForUrl(url, vendors);
      if (!vendor) return;
      const method = req.request.method || 'GET';
      const status = req.response.status || 0;
      const params = parseUrlParams(url);
      const rawPostBody = req.request.postData ? req.request.postData.text : null;
      const postParsed = rawPostBody ? parsePostBody(rawPostBody) : null;
      // parsePostBody() returns an array when the body is a GA4-style batch
      // of multiple hits (one per \r\n-separated line) -- normalize the
      // single-hit/JSON/no-body cases into a 1-item array so one request can
      // still produce multiple rows, one per hit, instead of silently
      // collapsing to just the first/last event name.
      const postHits = Array.isArray(postParsed) ? postParsed : [postParsed];
      // Script Load = any GET request to a .js path, regardless of vendor
      // category. Was previously restricted to vendor.type === 'tms', which
      // missed ads/other vendors' own loader scripts (Floodlight's
      // conversion_async.js, Zendesk's snippet.js/web-widget-*.js etc.) --
      // those got mislabeled as Pixel Hit/Request and slipped through filters.
      // Also catches container/config scripts served from an extensionless,
      // hashed path (e.g. Google's first-party-proxied gtag container at
      // metrics.example.com/metrics/<hash>) -- same content as gtm.js, just
      // without the .js suffix, so the URL check alone missed it and it fell
      // through to a fake "Event" row instead.
      let urlPath = '';
      try { urlPath = new URL(url).pathname; } catch (e) {}
      const mimeType = req.response.content && req.response.content.mimeType || '';
      const isScriptLoad = (/\.js$/i.test(urlPath) || /javascript/i.test(mimeType)) && method !== 'POST' && !rawPostBody;
      const requestHeaders = headersToObj(req.request.headers);
      const responseHeaders = headersToObj(req.response.headers);
      const evs = postHits.map(function(hit) {
        const postParams = hit && typeof hit === 'object' && !Array.isArray(hit) ? hit : null;
        const allParams = postParams ? { ...params, ...postParams } : params;
        const eventName = guessEventName(url, allParams, vendor);
        return addEvent({
          source: 'network', vendor, eventName,
          eventType: isScriptLoad ? 'Script Load' : guessEventType(allParams, vendor),
          url, params: allParams, postBody: rawPostBody || null, postData: postParams,
          pixelId: extractPixelId(vendor, url, postParams),
          requestHeaders, responseHeaders,
          ts: Date.now(), method, status, mimeType, responseBody: null, responseTruncated: false,
          warnings: detectWarnings(vendor, allParams)
        });
      });
      req.getContent(function(content) {
        if (typeof content !== 'string') return;
        evs.forEach(function(ev) {
          ev.responseTruncated = content.length > MAX_RESPONSE_CHARS;
          ev.responseBody = ev.responseTruncated ? content.slice(0, MAX_RESPONSE_CHARS) : content;
          if (selectedId === ev.id && activeDetailTab === 'raw') renderDetailTab(ev, 'raw');
        });
      });
    });
  }

  function guessEventName(url, params, vendor) {
    // Imagino names its calls with eventType (query string or top-level
    // JSON body key) -- checked first so a generic type=/event= param
    // on the same hit cannot win.
    if (vendor.id === 'imagino' && params.eventType) return params.eventType;
    if (params.event_name) return params.event_name;
    if (params.en) return params.en;
    if (params.ev) return params.ev;
    if (params.type) return params.type + (params.cat ? '/' + params.cat : '');
    if (params.event) return params.event;
    if (url.includes('gtm.js')) return 'gtm.js';
    if (url.includes('ns.html')) return 'noscript';
    const urlObj = new URL(url);
    // Walk back from the last path segment, skipping pure-numeric ones --
    // those are container/conversion IDs (e.g. .../pagead/form-data/865459073),
    // already surfaced in the Pixel ID column, not event names. Confirmed
    // live: a proxied Ads/Floodlight hit with no en=/event= param was
    // showing its raw numeric ID as if it were the event name.
    // Batch web-service calls end in the API key (ws.batch.com/web/{ver}/
    // {ev|atc|ats}/{apiKey}) -- name the call by its service shortname
    // instead of surfacing the key (already in the Pixel ID column).
    if (vendor.id === 'batch') {
      const svc = urlObj.pathname.match(/\/(ev|atc|ats)\/[A-Z0-9]+/i);
      if (svc) return { ev: 'event', atc: 'attributes_check', ats: 'attributes_send' }[svc[1].toLowerCase()];
    }
    const segments = urlObj.pathname.split('/').filter(Boolean);
    for (let i = segments.length - 1; i >= 0; i--) {
      if (!/^\d+$/.test(segments[i])) {
        // Wunderkind beacons encode the event in the path
        // (events.bouncex.net/track.gif/view%20item) -- decode for display.
        try { return decodeURIComponent(segments[i]); } catch (e) { return segments[i]; }
      }
    }
    return urlObj.hostname || vendor.shortName;
  }

  function guessEventType(params, vendor) {
    // Floodlight/Google Ads hits reclassified off Google's shared g/collect
    // gateway (see getVendorForUrl) still carry GA4-style param names
    // (en=page_view), not the ads-style ev=/event= capitalized names --
    // check those first so they don't fall through to a generic Pixel Hit.
    if (vendor.type === 'analytics' || vendor.id === 'floodlight' || vendor.id === 'google_ads') {
      if (params.en === 'page_view' || params.t === 'pageview' || params.event_name === 'page_view') return 'Pageview';
      if (vendor.type === 'analytics') return 'Event';
    }
    if (vendor.type === 'ads') {
      if (params.ev === 'PageView' || params.event === 'PageView') return 'PageView';
      if (params.ev === 'Purchase' || params.event === 'Purchase') return 'Purchase';
      return 'Pixel Hit';
    }
    if (vendor.type === 'tms') return 'Server Call';
    return 'Request';
  }

  function detectWarnings(vendor, params) {
    const warns = [];
    if (vendor.id === 'tiktok') {
      if (!params.email && !params.phone_number) warns.push('Missing email/phone');
      if (!params.content_id) warns.push('Missing content_id');
    }
    if (vendor.id === 'meta') {
      if (!params.em && !params.ph) warns.push('No hashed email/phone - limits Match Quality Score');
    }
    if (vendor.id === 'ga4') {
      if (!params.uid && !params.user_id) warns.push('No user_id set');
    }
    return warns;
  }

  function addEvent(ev) {
    ev.id = ++eventIdCounter;
    if (firstEventTs === null) firstEventTs = ev.ts;
    ev.timeStr = new Date(ev.ts).toLocaleTimeString('en-GB', { hour12: false }) + '.' + String(new Date(ev.ts).getMilliseconds()).padStart(3, '0');
    events.push(ev);
    updateVendorFilterOptions();
    renderEventList();
    return ev;
  }

  function clearEvents() {
    events = []; selectedId = null; checkedIds.clear(); firstEventTs = null;
    updateVendorFilterOptions();
    renderEventList(); showDetailEmpty(); updateCount();
  }

  function matchesRowFilter(ev, f) {
    if (f.column === 'eventType') return ev.eventType === f.value;
    if (f.column === 'vendor') return ev.vendor.shortName === f.value;
    if (f.column === 'method') return (ev.method || '') === f.value;
    if (f.column === 'status') return String(ev.status || '') === f.value;
    if (f.column === 'eventName') return ev.eventName === f.value;
    if (f.column === 'pixelId') return ev.pixelId === f.value;
    return false;
  }

  function getFiltered() {
    const vf = document.getElementById('filter-vendor').value;
    const showFilters = rowFilters.filter(f => f.mode === 'show');
    return events.filter(ev => {
      if (showFilters.length && !showFilters.some(f => matchesRowFilter(ev, f))) return false;
      for (const f of rowFilters) {
        if (f.mode === 'hide' && matchesRowFilter(ev, f)) return false;
      }
      if (vf && ev.vendor.shortName !== vf && ev.vendor.id !== vf) return false;
      return true;
    });
  }

  const COLUMN_LABELS = { eventType: 'Type', vendor: 'Vendor', method: 'Method', status: 'Status', eventName: 'Event', pixelId: 'Pixel ID' };

  function addRowFilter(column, value, mode) {
    if (value === undefined || value === null || value === '') return;
    if (rowFilters.some(f => f.column === column && f.value === value && f.mode === mode)) return;
    rowFilters.push({ column, value, mode });
    renderFilterChips();
    renderEventList();
  }

  function removeRowFilter(index) {
    rowFilters.splice(index, 1);
    renderFilterChips();
    renderEventList();
  }

  function renderFilterChips() {
    const bar = document.getElementById('filter-chips');
    if (!rowFilters.length) { bar.innerHTML = ''; return; }
    let html = rowFilters.map((f, i) =>
      '<span class="filter-chip filter-chip-' + f.mode + '">' + (f.mode === 'show' ? 'Show' : 'Hide') + ': ' +
      esc(COLUMN_LABELS[f.column] || f.column) + ' = ' + esc(f.value) +
      '<span class="chip-close" data-remove-filter="' + i + '">\u2715</span></span>'
    ).join('');
    if (rowFilters.length > 1) html += '<span class="chip-clear-all" id="chip-clear-all">Clear all</span>';
    bar.innerHTML = html;
  }

  document.getElementById('filter-chips').addEventListener('click', function(e) {
    const closeBtn = e.target.closest('[data-remove-filter]');
    if (closeBtn) { removeRowFilter(parseInt(closeBtn.dataset.removeFilter, 10)); return; }
    if (e.target.id === 'chip-clear-all') { rowFilters = []; renderFilterChips(); renderEventList(); }
  });

  // Right-click a row -> menu offering to Show-only or Hide rows matching
  // that row's Type / Vendor / Method / Status / Event Name / Pixel ID
  // (last one only offered when the row actually has one). A small mode
  // toggle at the top of the menu (default Hide, matches prior behavior)
  // controls which list a selected item joins; re-opening or toggling mode
  // re-renders the same menu without repositioning it. 'Show' filters OR
  // together into an allow-list (row must match at least one, when any
  // exist), 'Hide' filters OR together into a block-list (row dropped if it
  // matches any); the two groups AND together, so e.g. "Show: Vendor GA4"
  // plus "Hide: Type Script Load" isolates GA4 rows minus its script loads.
  // This replaced the old single-purpose "Hide Scripts" toggle with a
  // general mechanism, then grew a Show/Hide mode instead of hide-only.
  // Every mode button and item row is keyboard-focusable (tabindex="0"):
  // Arrow Up/Down moves focus between them (wrapping), Enter/Space activates
  // whichever is focused -- same effect as clicking it.
  const ctxMenu = document.getElementById('ctx-menu');

  function ctxMenuItems(ev) {
    const isDL = ev.source === 'datalayer';
    const items = [{ column: 'eventType', value: ev.eventType }];
    items.push({ column: 'vendor', value: ev.vendor.shortName, display: ev.vendor.name + ' (' + ev.vendor.shortName + ')' });
    if (!isDL) {
      if (ev.method) items.push({ column: 'method', value: ev.method });
      if (ev.status) items.push({ column: 'status', value: String(ev.status) });
    }
    items.push({ column: 'eventName', value: ev.eventName });
    if (ev.pixelId) items.push({ column: 'pixelId', value: ev.pixelId });
    return items;
  }

  // Focusable = the two mode buttons + every rendered item row, in DOM
  // order -- shared by keyboard arrow-navigation and by the "restore focus
  // to the active mode button" step after every re-render.
  function ctxFocusable() { return Array.from(ctxMenu.querySelectorAll('[tabindex]')); }

  function renderCtxMenuContents() {
    if (!ctxMenuEv) return;
    const items = ctxMenuItems(ctxMenuEv);
    let html = '<div class="ctx-menu-mode">' +
      '<span class="ctx-mode-btn' + (ctxMenuMode === 'show' ? ' active' : '') + '" tabindex="0" data-ctx-mode="show">Show</span>' +
      '<span class="ctx-mode-btn' + (ctxMenuMode === 'hide' ? ' active' : '') + '" tabindex="0" data-ctx-mode="hide">Hide</span>' +
      '</div>';
    html += '<div class="ctx-menu-label">' + (ctxMenuMode === 'show' ? 'Show only rows where...' : 'Hide rows where...') + '</div>';
    items.forEach(it => {
      const label = COLUMN_LABELS[it.column];
      const already = rowFilters.some(f => f.column === it.column && f.value === it.value && f.mode === ctxMenuMode);
      if (already) return;
      html += '<div class="ctx-menu-item" tabindex="0" data-hide-col="' + it.column + '" data-hide-val="' + esc(it.value) + '">' +
        label + ': <b>' + esc(it.display || it.value) + '</b></div>';
    });
    ctxMenu.innerHTML = html;
    // Re-rendering (e.g. after toggling mode) replaces every node, including
    // whichever one keyboard/mouse focus was just on -- restore it to the
    // now-active mode button so arrow-key navigation can continue seamlessly
    // instead of silently losing focus.
    const activeModeBtn = ctxMenu.querySelector('[data-ctx-mode="' + ctxMenuMode + '"]');
    if (activeModeBtn) activeModeBtn.focus();
  }

  function openCtxMenu(x, y, ev) {
    ctxMenuEv = ev;
    renderCtxMenuContents();
    ctxMenu.style.display = 'block';
    // Keep menu on-screen near the click point.
    const menuRect = { w: 220, h: ctxMenuItems(ev).length * 26 + 48 };
    const px = Math.min(x, window.innerWidth - menuRect.w - 8);
    const py = Math.min(y, window.innerHeight - menuRect.h - 8);
    ctxMenu.style.left = Math.max(4, px) + 'px';
    ctxMenu.style.top = Math.max(4, py) + 'px';
  }

  function closeCtxMenu() { ctxMenu.style.display = 'none'; ctxMenuEv = null; }

  document.getElementById('event-list').addEventListener('contextmenu', function(e) {
    const row = e.target.closest('[data-id]');
    if (!row) return;
    e.preventDefault();
    const id = parseInt(row.dataset.id, 10);
    const ev = events.find(x => x.id === id);
    if (!ev) return;
    openCtxMenu(e.clientX, e.clientY, ev);
  });

  ctxMenu.addEventListener('click', function(e) {
    const modeBtn = e.target.closest('[data-ctx-mode]');
    if (modeBtn) {
      // Re-rendering below detaches the node e.target points at (innerHTML
      // replaces it with a fresh element) -- if this click keeps bubbling to
      // the document-level "click outside closes the menu" listener, that
      // listener's `ctxMenu.contains(e.target)` check sees a detached node
      // and (wrongly) concludes the click landed outside the menu, closing
      // it right after it was supposed to just switch modes. Stopping
      // propagation here keeps the toggle click from ever reaching that
      // listener, whether it came from a real mouse click or a synthesized
      // one (the Enter/Space keyboard handler below calls .click(), which
      // dispatches and bubbles exactly like a real click).
      e.stopPropagation();
      ctxMenuMode = modeBtn.dataset.ctxMode;
      renderCtxMenuContents();
      return;
    }
    const item = e.target.closest('[data-hide-col]');
    if (!item) return;
    addRowFilter(item.dataset.hideCol, item.dataset.hideVal, ctxMenuMode);
    closeCtxMenu();
  });

  // Arrow keys move focus between the mode buttons and item rows (wrapping
  // at each end); Enter/Space activates whichever is currently focused,
  // same as clicking it. Attached to ctxMenu itself (not document) so it
  // only ever fires while focus is actually inside the menu.
  ctxMenu.addEventListener('keydown', function(e) {
    const focusable = ctxFocusable();
    if (!focusable.length) return;
    const current = focusable.indexOf(document.activeElement);
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      const dir = e.key === 'ArrowDown' ? 1 : -1;
      const next = ((current === -1 ? 0 : current + dir) % focusable.length + focusable.length) % focusable.length;
      focusable[next].focus();
    } else if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      if (current !== -1) focusable[current].click();
    }
  });

  document.addEventListener('click', function(e) {
    if (ctxMenu.style.display !== 'none' && !ctxMenu.contains(e.target)) closeCtxMenu();
  });
  document.addEventListener('keydown', function(e) { if (e.key === 'Escape') closeCtxMenu(); });
  window.addEventListener('blur', closeCtxMenu);

  // +Xms under 1s, +X.Ys under 1min, +XmYs beyond. Relative to the first
  // event captured this session (not the first *visible* row, so the delta
  // stays stable as filters change). Full wall-clock time still available
  // via the row's title tooltip.
  function formatDelta(ms) {
    if (ms < 1000) return '+' + Math.round(ms) + 'ms';
    if (ms < 60000) return '+' + (ms / 1000).toFixed(1) + 's';
    const m = Math.floor(ms / 60000);
    const s = Math.round((ms % 60000) / 1000);
    return '+' + m + 'm' + s + 's';
  }

  // Single source of truth: every row (DL push or network) opens ONLY the
  // bottom detail pane on click. No inline expand -> no possibility of two
  // panels showing the same event at once. The checkbox is a separate,
  // independent selection used only by the Copy button.
  function renderEventList() {
    const list = document.getElementById('event-list');
    const filtered = getFiltered();
    updateCount();
    updateCheckAllState(filtered);
    if (!filtered.length) {
      list.innerHTML = '<div class="no-events">' + (events.length === 0 ? 'Waiting for network requests...' : 'No events match the current filter.') + '</div>';
      return;
    }
    let html = '';
    // +/- next to the vendor badge = one-click multi-vendor selection. It
    // drives the same "Show: Vendor = X" row filters as the right-click
    // menu (same chips, OR-ed together), so there is one filter state.
    const shownVendors = new Set(rowFilters.filter(f => f.mode === 'show' && f.column === 'vendor').map(f => f.value));
    filtered.forEach((ev, idx) => {
      const isSel = ev.id === selectedId ? ' sel' : '';
      const isChecked = checkedIds.has(ev.id) ? ' checked' : '';
      const checkbox = '<span class="col-check"><input type="checkbox" class="row-check" data-check="' + ev.id + '"' + (checkedIds.has(ev.id) ? ' checked' : '') + '></span>';
      const isDL = ev.source === 'datalayer';
      const warnBadge = ev.warnings && ev.warnings.length ? '<span class="warn-badge">&#9888;' + ev.warnings.length + '</span>' : '';
      const vendorOn = shownVendors.has(ev.vendor.shortName);
      const badge = '<span class="vendor-toggle' + (vendorOn ? ' on' : '') + '" data-vendor-toggle="' + esc(ev.vendor.shortName) + '" title="' +
        (vendorOn ? 'Remove this vendor from the filter' : 'Add this vendor to the filter') + '">' + (vendorOn ? '\u2212' : '+') + '</span>' +
        '<span class="badge" style="background:' + ev.vendor.color + '">' + esc(ev.vendor.shortName) + '</span>';
      const deltaMs = firstEventTs === null ? 0 : ev.ts - firstEventTs;
      const timeCell = '<span class="col-time" title="' + esc(ev.timeStr) + '">' + esc(formatDelta(deltaMs)) + '</span>';
      if (isDL) {
        html += '<div class="ev-row dl-row' + isSel + isChecked + '" data-id="' + ev.id + '">' +
          checkbox +
          '<span class="col-num">' + (idx + 1) + '</span>' +
          '<span class="col-vendor">' + badge + '</span>' +
          '<span class="col-type" style="color:var(--muted)">' + esc(ev.eventType) + '</span>' +
          '<span class="col-event"><b>' + esc(ev.eventName) + '</b>' + warnBadge + '</span>' +
          '<span class="col-method"></span><span class="col-status"></span><span class="col-pixelid"></span>' +
          timeCell +
          '</div>';
      } else {
        const mc = ev.method === 'POST' ? 'method-post' : 'method-get';
        const sc = ev.status >= 400 ? 'status-err' : ev.status > 0 ? 'status-ok' : '';
        html += '<div class="ev-row' + isSel + isChecked + '" data-id="' + ev.id + '">' +
          checkbox +
          '<span class="col-num">' + (idx + 1) + '</span>' +
          '<span class="col-vendor">' + badge + '</span>' +
          '<span class="col-type" style="color:var(--muted)">' + esc(ev.eventType) + '</span>' +
          '<span class="col-event"><b>' + esc(ev.eventName) + '</b>' + warnBadge + '</span>' +
          '<span class="col-method ' + mc + '">' + esc(ev.method) + '</span>' +
          '<span class="col-status ' + sc + '">' + (ev.status || '') + '</span>' +
          '<span class="col-pixelid" title="' + esc(ev.pixelId || '') + '">' + esc(ev.pixelId || '') + '</span>' +
          timeCell +
          '</div>';
      }
    });
    list.innerHTML = html;
    if (!selectedId) list.scrollTop = list.scrollHeight;
  }

  function updateCheckAllState(filtered) {
    const cb = document.getElementById('check-all');
    if (!cb) return;
    const relevant = filtered.filter(ev => checkedIds.has(ev.id));
    cb.checked = filtered.length > 0 && relevant.length === filtered.length;
    cb.indeterminate = relevant.length > 0 && relevant.length < filtered.length;
  }

  function handleFmtToggle(id) {
    if (prettyDL.has(id)) prettyDL.delete(id); else prettyDL.add(id);
    if (selectedId === id) { const ev = events.find(e => e.id === id); if (ev) renderDetailTab(ev, 'params'); }
  }

  document.getElementById('event-list').addEventListener('click', function(e) {
    const checkbox = e.target.closest('[data-check]');
    if (checkbox) {
      const id = parseInt(checkbox.dataset.check, 10);
      if (checkedIds.has(id)) checkedIds.delete(id); else checkedIds.add(id);
      renderEventList();
      return;
    }
    const vendorToggle = e.target.closest('[data-vendor-toggle]');
    if (vendorToggle) {
      const value = vendorToggle.dataset.vendorToggle;
      const i = rowFilters.findIndex(f => f.mode === 'show' && f.column === 'vendor' && f.value === value);
      if (i >= 0) removeRowFilter(i); else addRowFilter('vendor', value, 'show');
      return;
    }
    const row = e.target.closest('[data-id]');
    if (!row) return;
    const id = parseInt(row.dataset.id, 10);
    selectedId = id;
    renderEventList();
    const ev = events.find(e => e.id === id);
    if (ev) showDetail(ev);
  });

  document.getElementById('check-all').addEventListener('click', function() {
    const filtered = getFiltered();
    const allChecked = filtered.length > 0 && filtered.every(ev => checkedIds.has(ev.id));
    // Unchecking clears the WHOLE selection, not just the currently filtered
    // rows -- checkedIds is deliberately kept independent of the active
    // filter (see buildCopyPayload/btn-copy), so ids checked under a
    // different filter scope would otherwise survive as invisible ghosts
    // and still get swept into the next Copy.
    if (allChecked) checkedIds.clear();
    else filtered.forEach(ev => checkedIds.add(ev.id));
    renderEventList();
  });

  // Lightweight export: URL, headers, request payload, response body -- a
  // small subset of a full HAR entry, meant to fit in a paste/prompt instead
  // of a multi-MB HAR file. Copies checked rows, or the currently open row
  // if nothing is checked.
  function buildCopyPayload(ev) {
    if (ev.source === 'datalayer') {
      return { source: 'datalayer', vendor: ev.vendor.name, varName: ev.varName, eventName: ev.eventName, time: ev.timeStr, data: ev.data };
    }
    let requestPayload = ev.postBody;
    try { requestPayload = JSON.parse(ev.postBody); } catch (e) {}
    let responseBody = ev.responseBody;
    try { responseBody = JSON.parse(ev.responseBody); } catch (e) {}
    return {
      source: 'network', vendor: ev.vendor.name, eventType: ev.eventType, eventName: ev.eventName,
      time: ev.timeStr, method: ev.method, status: ev.status, url: ev.url, pixelId: ev.pixelId || null,
      requestHeaders: ev.requestHeaders || {}, requestPayload: requestPayload || null,
      responseHeaders: ev.responseHeaders || {},
      responseBody: ev.responseBody == null ? null : (ev.responseTruncated ? { truncated: true, cap: MAX_RESPONSE_CHARS, value: responseBody } : responseBody)
    };
  }

  document.getElementById('btn-copy').addEventListener('click', function() {
    const btn = this;
    let targets = events.filter(ev => checkedIds.has(ev.id));
    if (!targets.length && selectedId) {
      const ev = events.find(e => e.id === selectedId);
      if (ev) targets = [ev];
    }
    if (!targets.length) {
      btn.textContent = 'Select a row first';
      setTimeout(() => { btn.textContent = '\uD83D\uDCCB Copy'; }, 1200);
      return;
    }
    const payload = targets.length === 1 ? buildCopyPayload(targets[0]) : targets.map(buildCopyPayload);
    navigator.clipboard.writeText(JSON.stringify(payload, null, 2)).then(() => {
      btn.textContent = 'Copied ' + targets.length + ' \u2713';
      btn.classList.add('copied');
      setTimeout(() => { btn.textContent = '\uD83D\uDCCB Copy'; btn.classList.remove('copied'); }, 1200);
    });
  });

  // Copies every vendor seen in the current capture as "supplier | tool",
  // one per line, same source and sort as the vendor filter dropdown.
  document.getElementById('btn-copy-suppliers').addEventListener('click', function() {
    const btn = this;
    const lines = [...document.getElementById('filter-vendor').options].filter(o => o.value).map(o => {
      const v = events.find(ev => ev.vendor.shortName === o.value).vendor;
      return (v.editor || v.name) + ' | ' + v.name;
    });
    if (!lines.length) {
      btn.textContent = 'No supplier yet';
      setTimeout(() => { btn.textContent = '\uD83D\uDCCB Suppliers'; }, 1200);
      return;
    }
    navigator.clipboard.writeText(lines.join('\n')).then(() => {
      btn.textContent = 'Copied ' + lines.length + ' \u2713';
      btn.classList.add('copied');
      setTimeout(() => { btn.textContent = '\uD83D\uDCCB Suppliers'; btn.classList.remove('copied'); }, 1200);
    });
  });

  document.getElementById('detail-pane').addEventListener('click', function(e) {
    const fmtBtn = e.target.closest('[data-fmt]');
    if (!fmtBtn) return;
    handleFmtToggle(parseInt(fmtBtn.dataset.fmt, 10));
  });

  function showDetailEmpty() {
    document.getElementById('detail-empty').style.display = '';
    document.getElementById('detail-content').style.display = 'none';
  }

  function showDetail(ev) {
    document.getElementById('detail-empty').style.display = 'none';
    document.getElementById('detail-content').style.display = '';
    const mc = ev.method === 'POST' ? 'var(--warn)' : 'var(--accent)';
    const sc = ev.status >= 400 ? 'var(--err)' : ev.status > 0 ? 'var(--ok)' : 'var(--muted)';
    document.getElementById('detail-header').innerHTML =
      (ev.method ? '<span style="color:' + mc + ';font-weight:700">' + esc(ev.method) + '</span>' : '') +
      (ev.status ? '<span style="color:' + sc + '">' + ev.status + '</span>' : '') +
      '<span class="badge" style="background:' + ev.vendor.color + '">' + esc(ev.vendor.shortName) + '</span>' +
      '<span>' + esc(ev.vendor.name) + '</span>' +
      '<span style="color:var(--muted)">- ' + esc(ev.eventType) + '</span>' +
      (ev.pixelId ? '<span style="color:var(--key-color)">ID: ' + esc(ev.pixelId) + '</span>' : '') +
      '<span style="margin-left:auto;color:var(--muted)">' + esc(ev.timeStr) + '</span>';
    const urlEl = document.getElementById('detail-url');
    urlEl.textContent = ev.url || '[DataLayer] ' + ev.varName;
    urlEl.title = 'Click to copy';
    urlEl.onclick = function() {
      navigator.clipboard.writeText(ev.url || '').then(() => {
        urlEl.style.color = 'var(--ok)';
        setTimeout(() => urlEl.style.color = '', 800);
      });
    };
    const warnEl = document.getElementById('detail-warnings');
    if (ev.warnings && ev.warnings.length) {
      warnEl.innerHTML = ev.warnings.map(w => '<span class="detail-warn">&#9888; ' + esc(w) + '</span>').join('');
      warnEl.style.display = '';
    } else {
      warnEl.innerHTML = '';
      warnEl.style.display = 'none';
    }
    const sanityTab = document.getElementById('btn-sanity');
    if (sanityTab) sanityTab.style.display = ev.source === 'datalayer' ? 'none' : '';
    renderDetailTab(ev, activeDetailTab);
  }

  // GA4/Universal Analytics Enhanced Ecommerce packs product/promo/impression
  // details into a single tilde-delimited string value (e.g. a `prN`/`ilNpiM`/
  // `promoN` param: "id123~nmFoo~pr9.99~qt1"), one 2-letter field code
  // immediately followed by its value per `~`-separated segment. Field codes
  // are a fixed whitelist checked longest/most-specific first -- a generic
  // regex can't tell where a 2-letter code ends and a numeric value begins
  // (e.g. "pr127.50" is price=127.50, not code "pr1" + value "27.50").
  const GA_ITEM_KEY_RE = /^(pr\d+|il\d+pi\d+|promo?\d+)$/i;
  const GA_ITEM_FIELD_LABELS = {
    id: 'ID / SKU', nm: 'Name', br: 'Brand', ca: 'Category', va: 'Variant',
    pr: 'Price', qt: 'Quantity', ps: 'Position', cc: 'Coupon Code',
    li: 'List ID', ln: 'List Name', lp: 'List Position', cr: 'Creative'
  };
  const GA_ITEM_ALPHA_CODES = Object.keys(GA_ITEM_FIELD_LABELS);

  function gaItemFieldLabel(code) {
    if (GA_ITEM_FIELD_LABELS[code]) return GA_ITEM_FIELD_LABELS[code];
    const m = code.match(/^c(\d+)$/);
    return m ? 'Category ' + m[1] : code;
  }

  function explodeGaItemString(str) {
    const customKeys = {};
    const fields = [];
    str.split('~').filter(s => s.length).forEach(seg => {
      let code = null, value = seg;
      for (const c of GA_ITEM_ALPHA_CODES) {
        if (seg.indexOf(c) === 0) { code = c; value = seg.slice(c.length); break; }
      }
      if (!code) {
        const m = seg.match(/^c(\d+)([\s\S]*)$/);
        if (m) { code = 'c' + m[1]; value = m[2]; }
      }
      if (!code) {
        const m = seg.match(/^k(\d+)([\s\S]*)$/);
        if (m) { customKeys[m[1]] = { name: m[2] }; return; }
      }
      if (!code) {
        const m = seg.match(/^v(\d+)([\s\S]*)$/);
        if (m) {
          if (customKeys[m[1]]) { customKeys[m[1]].value = m[2]; return; }
          code = 'v' + m[1]; value = m[2];
        }
      }
      if (!code) { fields.push({ label: seg, value: '' }); return; }
      fields.push({ label: gaItemFieldLabel(code), value });
    });
    Object.keys(customKeys).forEach(n => {
      const ck = customKeys[n];
      fields.push({ label: 'Custom param ' + n, value: (ck.name || '(unnamed)') + ' = ' + (ck.value !== undefined ? ck.value : '') });
    });
    return fields;
  }

  function renderParamValue(v, key) {
    if (v === '' || v === null || v === undefined) return '<span class="param-val empty">(empty)</span>';
    if (typeof v === 'object') return '<div class="param-val"><div class="dl-content dl-detail dl-pretty"><span class="dl-body">' + renderDLObj(v) + '</span></div></div>';
    if (typeof v === 'string' && key && GA_ITEM_KEY_RE.test(key) && v.indexOf('~') !== -1) {
      const obj = {};
      explodeGaItemString(v).forEach(f => { obj[f.label] = f.value === '' ? null : f.value; });
      return '<div class="param-val"><div class="dl-content dl-detail dl-pretty"><span class="dl-body">' + renderDLObj(obj) + '</span></div>' +
        '<div style="color:var(--muted);font-size:10px;margin-top:2px;word-break:break-all">raw: ' + esc(v) + '</div></div>';
    }
    return '<div class="param-val">' + esc(String(v)) + '</div>';
  }

  function renderDetailTab(ev, tab) {
    const body = document.getElementById('detail-body');
    if (tab === 'params') {
      const params = ev.source === 'datalayer' ? ev.data : (ev.params || {});
      if (!params || !Object.keys(params).length) { body.innerHTML = '<div style="padding:8px;color:var(--muted)">No parameters.</div>'; return; }
      let html = '';
      if (ev.source === 'datalayer') {
        const isPretty = prettyDL.has(ev.id);
        html = '<div class="dl-content dl-detail ' + (isPretty ? 'dl-pretty' : 'dl-compact') + '">' +
          '<button class="dl-fmt-btn" data-fmt="' + ev.id + '">' + (isPretty ? 'Compact' : 'Pretty') + '</button>' +
          '<span class="dl-body">' + (isPretty ? renderDLObj(params) : renderDLCompact(params)) + '</span></div>';
      } else {
        Object.entries(params).forEach(([k, v]) => {
          html += '<div class="param-row"><div class="param-key">' + esc(k) + '</div>' + renderParamValue(v, k) + '</div>';
        });
      }
      body.innerHTML = html;
    } else if (tab === 'raw') {
      let html = '<div style="font-weight:700;color:var(--muted);margin-bottom:2px">Request URL</div><div class="raw-body">' + esc(ev.url || '') + '</div>';
      if (ev.postBody) {
        let pretty = ev.postBody;
        try { pretty = JSON.stringify(JSON.parse(ev.postBody), null, 2); } catch (e) {}
        html += '<div style="margin-top:8px;font-weight:700;color:var(--muted)">Request Payload</div>' +
          '<div class="raw-body">' + esc(pretty) + '</div>';
      } else if (ev.source === 'datalayer' && ev.data) {
        html = '<div class="raw-body">' + esc(JSON.stringify(ev.data, null, 2)) + '</div>';
      }
      if (ev.source === 'network') {
        html += '<div style="margin-top:8px;font-weight:700;color:var(--muted)">Response' + (ev.mimeType ? ' <span style="font-weight:400">(' + esc(ev.mimeType) + ')</span>' : '') + '</div>';
        if (ev.responseBody === null) {
          html += '<div class="raw-body" style="color:var(--muted)">Loading...</div>';
        } else if (!ev.responseBody) {
          html += '<div class="raw-body" style="color:var(--muted)">(empty response body)</div>';
        } else {
          let respPretty = ev.responseBody;
          try { respPretty = JSON.stringify(JSON.parse(ev.responseBody), null, 2); } catch (e) {}
          html += '<div class="raw-body">' + esc(respPretty) + (ev.responseTruncated ? '\n\n... truncated (' + MAX_RESPONSE_CHARS + ' char cap)' : '') + '</div>';
        }
      }
      body.innerHTML = html;
    } else if (tab === 'info') {
      const v = ev.vendor;
      body.innerHTML = '<div class="vendor-info"><h3><span class="badge" style="background:' + v.color + ';margin-right:6px">' + esc(v.shortName) + '</span>' + esc(v.name) + '</h3>' +
        '<div class="info-row"><span class="info-label">Category:</span><span>' + esc(v.type) + '</span></div>' +
        '<div class="info-row"><span class="info-label">Type:</span><span>' + (v.builtin !== false ? 'Built-in' : 'Custom') + '</span></div>' +
        (v.datalayer ? '<div class="info-row"><span class="info-label">DataLayer:</span><span>' + esc(v.datalayer) + '</span></div>' : '') +
        '<div class="info-row"><span class="info-label">Patterns:</span><span>' + (v.patterns || []).map(p => '<code>' + esc(p) + '</code>').join(', ') + '</span></div></div>';
    } else if (tab === 'sanity') {
      renderSanityTab(ev, body);
    }
  }

  document.querySelectorAll('.dtab').forEach(btn => {
    btn.addEventListener('click', function() {
      activeDetailTab = this.dataset.tab;
      document.querySelectorAll('.dtab').forEach(b => b.classList.remove('active'));
      this.classList.add('active');
      const ev = events.find(e => e.id === selectedId);
      if (ev) renderDetailTab(ev, activeDetailTab);
    });
  });

  function renderSanityTab(ev, body) {
    if (ev.source === 'datalayer') {
      body.innerHTML = '<div class="sanity-wrap"><div class="sanity-no-key">Sanity Check is only available for network tag calls (GA4, Meta, TikTok, Floodlight...).</div></div>';
      return;
    }
    body.innerHTML = '<div class="sanity-wrap">' +
      '<div class="sanity-no-key" style="margin-bottom:12px">Builds a detailed prompt with all tag parameters and opens <b>ChatGPT</b> in a new tab.<br>Paste the prompt (Ctrl+V) and ask for a sanity check.</div>' +
      '<button class="sanity-run-btn" id="sanity-btn">&#10022; Sanity Check with ChatGPT</button>' +
      (ev._promptCopied ? '<div style="color:var(--ok);font-size:11px;margin-top:8px">Prompt copied - paste in ChatGPT (Ctrl+V)</div>' : '') +
      '</div>';
    document.getElementById('sanity-btn').addEventListener('click', () => {
      const prompt = buildChatGPTPrompt(ev);
      navigator.clipboard.writeText(prompt).then(() => {
        ev._promptCopied = true;
        renderSanityTab(ev, body);
        window.open('https://chatgpt.com/', '_blank');
      }).catch(() => window.open('https://chatgpt.com/', '_blank'));
    });
  }

  function buildChatGPTPrompt(ev) {
    const params = ev.params || {};
    const paramLines = Object.entries(params).map(([k, v]) => '  ' + k + ': ' + (v === '' || v === null ? '(empty)' : (typeof v === 'object' ? JSON.stringify(v) : v))).join('\n') || '  (none)';
    return 'You are a digital marketing tracking expert. Please do a sanity check on this tag call.\n\nVendor: ' + ev.vendor.name + ' (' + ev.vendor.shortName + ')\nEvent type: ' + ev.eventType + '\nEvent name: ' + ev.eventName + '\nHTTP method: ' + (ev.method || 'GET') + '\nHTTP status: ' + ev.status + '\nURL: ' + (ev.url || 'N/A') + '\n\nParameters:\n' + paramLines + (ev.warnings && ev.warnings.length ? '\n\nPre-detected warnings:\n' + ev.warnings.map(w => '  - ' + w).join('\n') : '') + '\n\nPlease check: are all required parameters present? Are the values correctly formatted? Any red flags for this specific vendor and event type?';
  }

  function renderDLObj(o, depth) {
    depth = depth || 0;
    const pad = '  '.repeat(depth);
    if (o === null) return '<span class="dl-null">null</span>';
    if (o === undefined) return '<span class="dl-null">undefined</span>';
    if (typeof o === 'string') return '<span class="dl-s">"' + esc(o) + '"</span>';
    if (typeof o === 'number') return '<span class="dl-n">' + o + '</span>';
    if (typeof o === 'boolean') return '<span class="dl-b">' + o + '</span>';
    if (typeof o !== 'object') return esc(String(o));
    const arr = Array.isArray(o);
    const keys = Object.keys(o);
    if (!keys.length) return arr ? '[]' : '{}';
    let s = arr ? '[' : '{';
    keys.forEach((k, i) => {
      const comma = i < keys.length - 1 ? ',' : '';
      const val = renderDLObj(o[k], depth + 1);
      s += arr ? '\n' + pad + '  ' + val + comma : '\n' + pad + '  <span class="dl-k">"' + esc(k) + '"</span>: ' + val + comma;
    });
    return s + '\n' + pad + (arr ? ']' : '}');
  }

  function renderDLCompact(o) {
    if (o === null) return '<span class="dl-null">null</span>';
    if (o === undefined) return '<span class="dl-null">undefined</span>';
    if (typeof o === 'string') return '<span class="dl-s">"' + esc(o) + '"</span>';
    if (typeof o === 'number') return '<span class="dl-n">' + o + '</span>';
    if (typeof o === 'boolean') return '<span class="dl-b">' + o + '</span>';
    if (typeof o !== 'object') return esc(String(o));
    const arr = Array.isArray(o);
    const keys = Object.keys(o);
    if (!keys.length) return arr ? '[]' : '{}';
    const parts = keys.map(k => { const val = renderDLCompact(o[k]); return arr ? val : '<span class="dl-k">"' + esc(k) + '"</span>: ' + val; });
    return (arr ? '[ ' : '{ ') + parts.join(', ') + (arr ? ' ]' : ' }');
  }

  function esc(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function updateCount() {
    const filtered = getFiltered();
    document.getElementById('ev-count').textContent = filtered.length === events.length ? events.length + ' events' : filtered.length + ' / ' + events.length + ' events';
  }

  // Vendor filter dropdown shows ONLY vendors actually seen in the current
  // capture (not the full static vendors.js list) -- rebuilt from `events`
  // on every add/clear. Preserves the current selection across rebuilds if
  // that vendor is still present; resets to "All vendors" otherwise (e.g.
  // after Clear). Sort stays supplier (editor) then tool name, same as before.
  function updateVendorFilterOptions() {
    const sel = document.getElementById('filter-vendor');
    const prevValue = sel.value;
    const seen = new Map();
    events.forEach(ev => { if (!seen.has(ev.vendor.shortName)) seen.set(ev.vendor.shortName, ev.vendor); });
    const sorted = [...seen.values()].sort((a, b) => {
      const ea = (a.editor || a.name).toLowerCase();
      const eb = (b.editor || b.name).toLowerCase();
      if (ea !== eb) return ea < eb ? -1 : 1;
      return a.name.toLowerCase() < b.name.toLowerCase() ? -1 : 1;
    });
    sel.innerHTML = '<option value="">All vendors</option>';
    sorted.forEach(v => {
      const editor = v.editor || v.name;
      const label = editor === v.name ? v.name : editor + ' - ' + v.name;
      const opt = document.createElement('option');
      opt.value = v.shortName;
      opt.textContent = label;
      sel.appendChild(opt);
    });
    if ([...sel.options].some(o => o.value === prevValue)) sel.value = prevValue;
  }

  document.getElementById('btn-rec').addEventListener('click', function() {
    recording = !recording;
    this.textContent = recording ? 'REC' : 'Paused';
    this.className = recording ? 'btn-rec active' : 'btn-rec paused';
  });

  document.getElementById('btn-clear').addEventListener('click', clearEvents);
  document.getElementById('filter-vendor').addEventListener('change', renderEventList);
  document.getElementById('btn-opts').addEventListener('click', function() { chrome.runtime.openOptionsPage(); });

  (function() {
    const resizer = document.getElementById('resizer');
    const pane = document.getElementById('detail-pane');
    let dragging = false, startY, startH;
    resizer.addEventListener('mousedown', function(e) { dragging = true; startY = e.clientY; startH = pane.offsetHeight; document.body.style.cursor = 'ns-resize'; document.body.style.userSelect = 'none'; });
    document.addEventListener('mousemove', function(e) { if (!dragging) return; const newH = Math.max(80, Math.min(600, startH + (startY - e.clientY))); pane.style.height = newH + 'px'; });
    document.addEventListener('mouseup', function() { if (dragging) { dragging = false; document.body.style.cursor = ''; document.body.style.userSelect = ''; } });
  })();

  renderEventList();
})();
