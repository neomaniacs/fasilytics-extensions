// FASilytics Tag Inspector - Options JS

(function() {
  'use strict';

  let builtinState = {};
  let customVendors = [];
  let extraPatterns = {};

  chrome.storage.local.get(
    ['tagspy_vendors', 'tagspy_custom_vendors', 'tagspy_clear_on_nav', 'tagspy_extra_patterns'],
    function(result) {
      builtinState  = result.tagspy_vendors || {};
      customVendors = result.tagspy_custom_vendors || [];
      extraPatterns = result.tagspy_extra_patterns || {};
      document.getElementById('pref-clear-nav').checked = result.tagspy_clear_on_nav || false;
      renderBuiltinVendors();
      renderCustomVendors();
      populateVendorSelect();
      renderExtraPatternList();
    }
  );

  document.getElementById('pref-clear-nav').addEventListener('change', function() {
    chrome.storage.local.set({ tagspy_clear_on_nav: this.checked }, showSaved);
  });

  function renderBuiltinVendors() {
    const list = document.getElementById('builtin-list');
    let html = '';
    TAGSPY_DEFAULT_VENDORS.forEach(v => {
      const enabled = builtinState[v.id] !== undefined ? builtinState[v.id] : v.enabled;
      html += `<div class="vendor-row">
        <label class="toggle">
          <input type="checkbox" ${enabled ? 'checked' : ''} data-vendor-id="${v.id}">
          <span class="toggle-track"></span>
        </label>
        <span class="vendor-badge" style="background:${v.color}">${esc(v.shortName)}</span>
        <span class="vendor-name">${esc(v.name)}</span>
        <span class="vendor-cat">${v.type}</span>
        <span class="vendor-pat">${v.patterns.slice(0, 2).map(esc).join(' | ')}</span>
        ${v.datalayer ? `<span class="vendor-dl">DL: ${esc(v.datalayer)}</span>` : ''}
      </div>`;
    });
    list.innerHTML = html;
    list.addEventListener('change', function(e) {
      const id = e.target.dataset.vendorId;
      if (id) { builtinState[id] = e.target.checked; chrome.storage.local.set({ tagspy_vendors: builtinState }, showSaved); }
    });
  }

  function renderCustomVendors() {
    const list = document.getElementById('custom-list');
    if (!customVendors.length) {
      list.innerHTML = '<div class="empty-state">No custom vendors added yet.</div>';
      return;
    }
    let html = '';
    customVendors.forEach((v, i) => {
      html += `<div class="vendor-row">
        <label class="toggle">
          <input type="checkbox" ${v.enabled !== false ? 'checked' : ''} data-custom-idx="${i}">
          <span class="toggle-track"></span>
        </label>
        <span class="vendor-badge" style="background:${esc(v.color)}">${esc(v.shortName)}</span>
        <span class="vendor-name">${esc(v.name)}</span>
        <span class="vendor-cat">${esc(v.type || 'other')}</span>
        <span class="vendor-pat">${(v.patterns || []).slice(0, 2).map(esc).join(' | ')}</span>
        ${v.datalayer ? `<span class="vendor-dl">DL: ${esc(v.datalayer)}</span>` : ''}
        <button class="btn-delete" data-delete-idx="${i}" title="Delete vendor">&#10005;</button>
      </div>`;
    });
    list.innerHTML = html;
    list.addEventListener('change', function(e) {
      const idx = e.target.dataset.customIdx;
      if (idx !== undefined) { customVendors[parseInt(idx)].enabled = e.target.checked; saveCustomVendors(); }
    });
    list.addEventListener('click', function(e) {
      const btn = e.target.closest('[data-delete-idx]');
      if (!btn) return;
      const idx = parseInt(btn.dataset.deleteIdx);
      const name = customVendors[idx].name;
      const deletedId = customVendors[idx].id;
      if (!confirm(`Delete vendor "${name}"?`)) return;
      customVendors.splice(idx, 1);
      saveCustomVendors();
      renderCustomVendors();
      populateVendorSelect();
      if (extraPatterns[deletedId]) {
        delete extraPatterns[deletedId];
        saveExtraPatterns();
        renderExtraPatternList();
      }
    });
  }

  document.getElementById('btn-add-vendor').addEventListener('click', function() {
    const name = document.getElementById('ov-name').value.trim();
    const shortName = document.getElementById('ov-short').value.trim().toUpperCase().slice(0, 6);
    const color = document.getElementById('ov-color').value;
    const type = document.getElementById('ov-type').value;
    const patternsRaw = document.getElementById('ov-patterns').value.trim();
    const datalayer = document.getElementById('ov-datalayer').value.trim();
    const msgEl = document.getElementById('add-vendor-msg');

    if (!name) { showMsg(msgEl, 'Name is required.', 'err'); return; }
    if (!shortName) { showMsg(msgEl, 'Short code is required.', 'err'); return; }
    if (!patternsRaw) { showMsg(msgEl, 'At least one URL pattern is required.', 'err'); return; }

    const patterns = patternsRaw.split('\n').map(s => s.trim()).filter(Boolean);
    for (const pat of patterns) {
      try { new RegExp(pat); } catch(e) { showMsg(msgEl, `Invalid regex: ${pat}`, 'err'); return; }
    }

    const exists = [...TAGSPY_DEFAULT_VENDORS, ...customVendors].some(v => v.shortName === shortName);
    if (exists) { showMsg(msgEl, `Short code "${shortName}" already exists.`, 'err'); return; }

    customVendors.push({ id: 'custom_' + Date.now(), name, shortName, color, patterns, datalayer: datalayer || undefined, type, enabled: true, builtin: false });
    saveCustomVendors();
    renderCustomVendors();
    populateVendorSelect();

    document.getElementById('ov-name').value = '';
    document.getElementById('ov-short').value = '';
    document.getElementById('ov-color').value = '#888888';
    document.getElementById('ov-patterns').value = '';
    document.getElementById('ov-datalayer').value = '';
    document.getElementById('ov-type').value = 'ads';
    showMsg(msgEl, `Vendor "${name}" added.`, 'ok');
  });

  function saveCustomVendors() {
    chrome.storage.local.set({ tagspy_custom_vendors: customVendors }, showSaved);
  }

  function findVendor(id) {
    return TAGSPY_DEFAULT_VENDORS.find(v => v.id === id) || customVendors.find(v => v.id === id);
  }

  function populateVendorSelect() {
    const sel = document.getElementById('ep-vendor');
    const prevValue = sel.value;
    const sorted = [...TAGSPY_DEFAULT_VENDORS, ...customVendors].sort((a, b) => {
      const ea = (a.editor || a.name).toLowerCase();
      const eb = (b.editor || b.name).toLowerCase();
      if (ea !== eb) return ea < eb ? -1 : 1;
      return a.name.toLowerCase() < b.name.toLowerCase() ? -1 : 1;
    });
    sel.innerHTML = '';
    sorted.forEach(v => {
      const editor = v.editor || v.name;
      const label = (editor === v.name ? v.name : editor + ' - ' + v.name) + ' (' + v.shortName + ')';
      const opt = document.createElement('option');
      opt.value = v.id;
      opt.textContent = label;
      sel.appendChild(opt);
    });
    if ([...sel.options].some(o => o.value === prevValue)) sel.value = prevValue;
  }

  function renderExtraPatternList() {
    const list = document.getElementById('extra-pattern-list');
    const rows = [];
    Object.keys(extraPatterns).forEach(vendorId => {
      const v = findVendor(vendorId);
      if (!v) return;
      (extraPatterns[vendorId] || []).forEach((pattern, idx) => rows.push({ vendorId, idx, pattern, v }));
    });
    if (!rows.length) {
      list.innerHTML = '<div class="empty-state">No custom tracking domains added yet.</div>';
      return;
    }
    list.innerHTML = rows.map(r =>
      `<div class="vendor-row">
        <span class="vendor-badge" style="background:${esc(r.v.color)}">${esc(r.v.shortName)}</span>
        <span class="vendor-name">${esc(r.v.name)}</span>
        <span class="vendor-pat" title="${esc(r.pattern)}" style="flex:1;max-width:none">${esc(r.pattern)}</span>
        <button class="btn-delete" data-del-vendor="${esc(r.vendorId)}" data-del-idx="${r.idx}" title="Delete pattern">&#10005;</button>
      </div>`
    ).join('');
  }

  function saveExtraPatterns() {
    chrome.storage.local.set({ tagspy_extra_patterns: extraPatterns }, showSaved);
  }

  document.getElementById('extra-pattern-list').addEventListener('click', function(e) {
    const btn = e.target.closest('[data-del-vendor]');
    if (!btn) return;
    const vendorId = btn.dataset.delVendor;
    const idx = parseInt(btn.dataset.delIdx, 10);
    if (!extraPatterns[vendorId]) return;
    extraPatterns[vendorId].splice(idx, 1);
    if (!extraPatterns[vendorId].length) delete extraPatterns[vendorId];
    saveExtraPatterns();
    renderExtraPatternList();
  });

  document.getElementById('btn-suggest-url').addEventListener('click', function() {
    const msgEl = document.getElementById('add-pattern-msg');
    chrome.storage.local.get(['tagspy_last_page_url'], function(r) {
      if (r && r.tagspy_last_page_url) {
        document.getElementById('ep-pattern').value = r.tagspy_last_page_url;
      } else {
        showMsg(msgEl, 'No page inspected yet - open the DevTools panel on a page first.', 'err');
      }
    });
  });

  document.getElementById('btn-add-pattern').addEventListener('click', function() {
    const vendorId = document.getElementById('ep-vendor').value;
    const pattern = document.getElementById('ep-pattern').value.trim();
    const msgEl = document.getElementById('add-pattern-msg');

    if (!vendorId) { showMsg(msgEl, 'Pick a vendor.', 'err'); return; }
    if (!pattern) { showMsg(msgEl, 'URL pattern is required.', 'err'); return; }
    try { new RegExp(pattern); } catch (e) { showMsg(msgEl, `Invalid regex: ${pattern}`, 'err'); return; }

    const vendor = findVendor(vendorId);
    if (!vendor) { showMsg(msgEl, 'Unknown vendor.', 'err'); return; }

    const existing = [...(vendor.patterns || []), ...(extraPatterns[vendorId] || [])];
    if (existing.includes(pattern)) { showMsg(msgEl, 'That pattern is already set for this vendor.', 'err'); return; }

    if (!extraPatterns[vendorId]) extraPatterns[vendorId] = [];
    extraPatterns[vendorId].push(pattern);
    saveExtraPatterns();
    renderExtraPatternList();
    document.getElementById('ep-pattern').value = '';
    showMsg(msgEl, `Pattern added to ${vendor.name}.`, 'ok');
  });

  function showSaved() {
    const el = document.getElementById('save-msg');
    el.textContent = 'Settings saved';
    el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), 2000);
  }

  function showMsg(el, msg, cls) {
    el.textContent = msg;
    el.className = 'form-msg ' + cls;
    setTimeout(() => { el.textContent = ''; el.className = 'form-msg'; }, 4000);
  }

  function esc(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
})();
