// Tech Inspector — content script (isolated world).
//
// Collects what the fingerprints need from the document: script URLs, inline
// script text, meta tags, DOM selector hits, outer HTML and visible text.
// Page-world JS globals are read by the background through
// chrome.scripting.executeScript({ world: 'MAIN' }) — never by injecting a
// <script> tag, which site CSPs block (lesson from TagSpy).
//
// Collection runs at document_idle, then again after 3 s and 8 s because tag
// managers keep adding scripts well after load. Each run sends the full
// snapshot; the background merges request-level data on top.

(function () {
  'use strict';
  if (window.__fasilyticsTechInspector) return;
  window.__fasilyticsTechInspector = true;

  const LIMITS = { html: 1024 * 1024, text: 200 * 1024, inlineScript: 200 * 1024, inlineTotal: 3 * 1024 * 1024, domNodes: 5, attrValue: 2000 };
  let plan = null;

  function send(msg) {
    try { return chrome.runtime.sendMessage(msg); } catch (e) { return Promise.resolve(); }
  }

  function collect() {
    const scriptSrc = [];
    const scripts = [];
    let inlineTotal = 0;
    for (const s of document.scripts) {
      if (s.src) { scriptSrc.push(s.src); continue; }
      const t = s.textContent;
      if (!t || inlineTotal >= LIMITS.inlineTotal) continue;
      const chunk = t.length > LIMITS.inlineScript ? t.slice(0, LIMITS.inlineScript) : t;
      scripts.push(chunk);
      inlineTotal += chunk.length;
    }

    const meta = {};
    for (const m of document.querySelectorAll('meta[name], meta[property]')) {
      const key = (m.getAttribute('name') || m.getAttribute('property') || '').toLowerCase();
      const content = m.getAttribute('content');
      if (!key || content === null) continue;
      (meta[key] = meta[key] || []).push(content);
    }

    const dom = {};
    for (const sel of (plan && plan.dom) || []) {
      let nodes;
      try { nodes = document.querySelectorAll(sel); } catch (e) { continue; }
      if (!nodes.length) continue;
      const list = [];
      for (const n of Array.from(nodes).slice(0, LIMITS.domNodes)) {
        const attributes = {};
        for (const a of n.attributes || []) attributes[a.name] = a.value.length > LIMITS.attrValue ? a.value.slice(0, LIMITS.attrValue) : a.value;
        list.push({ text: (n.textContent || '').slice(0, 500), attributes, properties: {} });
      }
      dom[sel] = list;
    }

    let html = '';
    try { html = document.documentElement.outerHTML; } catch (e) { /* ignore */ }
    if (html.length > LIMITS.html) html = html.slice(0, LIMITS.html);
    let text = '';
    try { text = (document.body && document.body.innerText) || ''; } catch (e) { /* ignore */ }
    if (text.length > LIMITS.text) text = text.slice(0, LIMITS.text);

    return {
      url: location.href,
      title: document.title || '',
      lang: document.documentElement.getAttribute('lang') || '',
      scriptSrc, scripts, meta, dom, html, text,
      links: Array.from(document.querySelectorAll('link[rel][href]')).slice(0, 200).map(l => ({ rel: l.rel, href: l.href })),
      collectedAt: Date.now()
    };
  }

  async function run() {
    if (!plan) {
      try { plan = await send({ type: 'ti:plan' }); } catch (e) { plan = { dom: [] }; }
      if (!plan) plan = { dom: [] };
    }
    const data = collect();
    await send({ type: 'ti:page', data });
  }

  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (msg && msg.type === 'ti:collect') { run().catch(() => {}).then(() => reply({ ok: true })); return true; }
    return false;
  });

  // "Extension context invalidated" after a reload: stay silent on the page.
  const quiet = () => run().catch(() => {});
  quiet();
  setTimeout(quiet, 3000);
  setTimeout(quiet, 8000);
})();
