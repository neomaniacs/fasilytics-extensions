(function () {
  'use strict';
  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  let disabled = new Set();

  function save() {
    chrome.storage.sync.set({ disabledCats: [...disabled] }, () => { $('#saved').textContent = 'Saved'; setTimeout(() => { $('#saved').textContent = ''; }, 1200); });
  }

  chrome.runtime.sendMessage({ type: 'ti:catalog' }, (r) => {
    if (!r) return;
    const counts = {};
    for (const t of r.list) for (const c of t[1]) counts[c] = (counts[c] || 0) + 1;
    chrome.storage.sync.get('disabledCats', (st) => {
      disabled = new Set((st && st.disabledCats) || []);
      const cats = Object.entries(r.categories).sort((a, b) => a[1].name.localeCompare(b[1].name));
      $('#cats').innerHTML = cats.map(([id, c]) => `<label class="row"><input type="checkbox" data-id="${id}" ${disabled.has(Number(id)) ? '' : 'checked'}>${esc(c.name)}<span class="n">${counts[id] || 0}</span></label>`).join('');
      $('#cats').addEventListener('change', (e) => {
        const id = Number(e.target.dataset.id);
        if (e.target.checked) disabled.delete(id); else disabled.add(id);
        save();
      });
      $('#all').addEventListener('click', () => { disabled.clear(); document.querySelectorAll('#cats input').forEach((i) => { i.checked = true; }); save(); });
      $('#none').addEventListener('click', () => { document.querySelectorAll('#cats input').forEach((i) => { i.checked = false; disabled.add(Number(i.dataset.id)); }); save(); });
      const m = r.meta || {};
      $('#meta').innerHTML = `<dt>Source</dt><dd>${esc(m.source || '')}</dd><dt>Commit</dt><dd>${esc(m.commit || '')} · ${esc(m.commitDate || '')}</dd><dt>Technologies</dt><dd>${esc(m.count || '')}</dd><dt>Imported</dt><dd>${esc(m.importedAt || '')}</dd>`;
    });
  });
})();
