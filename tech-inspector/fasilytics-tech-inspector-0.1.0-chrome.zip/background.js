// Tech Inspector — background (service worker on Chrome, background script on
// Firefox). Loaded after engine.js and ids.js.
//
// Responsibilities:
//   - remember every request URL and the main-frame response headers per tab
//   - receive DOM snapshots from content.js, read page-world globals in the
//     MAIN world, read cookies, run the engine + the ID layer
//   - keep results in memory and in storage.session (the Chrome service
//     worker is killed after ~30 s idle; the popup must still get an answer)
//   - badge = number of technologies found

(function () {
  'use strict';

  const Engine = self.TechEngine;
  const Ids = self.TechIds;
  const LIMITS = { requests: 3000 };

  const tabs = new Map();      // tabId -> state
  let technologies = null;     // { name: def }
  let categories = null;
  let groups = null;
  let meta = null;
  let plan = null;             // { js, jsKeys, dom }
  let loading = null;

  // Swallows sync throws AND rejected promises (chrome.* APIs reject on a
  // closed tab: "No tab with id"). Returns the promise so callers can await.
  function safe(fn) {
    try {
      const r = fn();
      if (r && typeof r.catch === 'function') return r.catch(() => undefined);
      return r;
    } catch (e) { return undefined; }
  }

  async function loadData() {
    if (technologies) return;
    if (loading) return loading;
    loading = (async () => {
      const get = async (f) => (await fetch(chrome.runtime.getURL('data/' + f))).json();
      [technologies, categories, groups, meta] = await Promise.all([get('technologies.json'), get('categories.json'), get('groups.json'), get('meta.json').catch(() => ({}))]);
      const p = Engine.collectionPlan(technologies);
      const q = Ids.collectionPlan();
      plan = { js: [...new Set([...p.js, ...q.js])], jsKeys: q.jsKeys, dom: [...new Set([...p.dom, ...q.dom])] };
    })();
    return loading;
  }

  function state(tabId) {
    let s = tabs.get(tabId);
    if (!s) {
      s = { tabId, url: '', requests: [], requestSet: new Set(), headers: {}, page: null, js: {}, jsKeys: {}, cookies: {}, result: null, timer: null };
      tabs.set(tabId, s);
    }
    return s;
  }

  function reset(tabId, url) {
    const s = state(tabId);
    s.url = url || '';
    s.requests = []; s.requestSet = new Set(); s.headers = {}; s.page = null; s.js = {}; s.jsKeys = {}; s.cookies = {}; s.result = null;
    setBadge(tabId, 0);
    safe(() => chrome.storage.session.remove('net:' + tabId));
  }

  // Network capture mirrored in storage.session: the service worker is killed
  // after ~30 s idle and a later rescan would miss headers and requests.
  function saveNet(tabId) {
    const s = state(tabId);
    safe(() => chrome.storage.session.set({ ['net:' + tabId]: { url: s.url, headers: s.headers, requests: s.requests.slice(0, 1000) } }));
  }

  async function restoreNet(tabId) {
    const s = state(tabId);
    if (Object.keys(s.headers).length) return;
    const saved = ((await safe(() => chrome.storage.session.get('net:' + tabId))) || {})['net:' + tabId];
    if (!saved) return;
    const strip = (u) => String(u || '').split('#')[0];
    if (s.url && strip(s.url) !== strip(saved.url)) return;
    s.url = s.url || saved.url;
    s.headers = saved.headers || {};
    for (const u of saved.requests || []) if (!s.requestSet.has(u)) { s.requestSet.add(u); s.requests.push(u); }
  }

  // ---------- network ----------

  chrome.webRequest.onBeforeRequest.addListener((d) => {
    if (d.tabId < 0) return;
    const s = state(d.tabId);
    if (d.type === 'main_frame') { reset(d.tabId, d.url); return; }
    if (s.requestSet.has(d.url) || s.requests.length >= LIMITS.requests) return;
    s.requestSet.add(d.url);
    s.requests.push(d.url);
    schedule(d.tabId, 1200);
  }, { urls: ['http://*/*', 'https://*/*'] });

  chrome.webRequest.onHeadersReceived.addListener((d) => {
    if (d.tabId < 0 || d.type !== 'main_frame') return;
    const s = state(d.tabId);
    s.url = d.url;
    const h = {};
    for (const { name, value } of d.responseHeaders || []) {
      const k = name.toLowerCase();
      (h[k] = h[k] || []).push(value || '');
    }
    s.headers = h;
    saveNet(d.tabId);
  }, { urls: ['http://*/*', 'https://*/*'] }, ['responseHeaders']);

  chrome.tabs.onRemoved.addListener((tabId) => { tabs.delete(tabId); safe(() => chrome.storage.session.remove(['tab:' + tabId, 'net:' + tabId])); });

  // ---------- page-world globals ----------

  function readGlobals(paths, keyPaths) {
    const get = (p) => { try { let o = window; for (const k of p.split('.')) { if (o === null || o === undefined) return undefined; o = o[k]; } return o; } catch (e) { return undefined; } };
    const js = {};
    for (const p of paths) {
      const v = get(p);
      if (v === undefined || v === null) continue;
      const t = typeof v;
      if (t === 'string' || t === 'number' || t === 'boolean') js[p] = String(v).slice(0, 500);
      else if (Array.isArray(v)) { try { js[p] = JSON.stringify(v).slice(0, 500); } catch (e) { js[p] = 'true'; } }
      else js[p] = 'true';
    }
    const jsKeys = {};
    for (const p of keyPaths) {
      const v = get(p);
      if (v && typeof v === 'object') { try { jsKeys[p] = Object.keys(v).slice(0, 200); } catch (e) { /* ignore */ } }
    }
    return { js, jsKeys };
  }

  async function collectGlobals(tabId) {
    try {
      const res = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: readGlobals, args: [plan.js, plan.jsKeys] });
      const r = res && res[0] && res[0].result;
      if (r) { const s = state(tabId); s.js = r.js || {}; s.jsKeys = r.jsKeys || {}; }
    } catch (e) { /* chrome:// pages, closed tab, CSP sandbox: keep what we have */ }
  }

  async function collectCookies(tabId) {
    const s = state(tabId);
    // s.url is only set by webRequest; after an extension reload the page may
    // already be open, so fall back to what the content script reported.
    const url = s.url || (s.page && s.page.url);
    if (!url) return;
    try {
      const list = await chrome.cookies.getAll({ url });
      const c = {};
      for (const k of list) c[k.name] = k.value;
      s.cookies = c;
      s.cookieList = list.map(k => ({ name: k.name, domain: k.domain, expires: k.expirationDate || null, session: !!k.session, httpOnly: !!k.httpOnly, size: (k.value || '').length }));
    } catch (e) { /* no cookies permission for this scheme */ }
  }

  // ---------- analysis ----------

  function schedule(tabId, delay) {
    const s = state(tabId);
    if (!s.page) return; // nothing to analyze until the content script reported
    clearTimeout(s.timer);
    s.timer = setTimeout(() => analyze(tabId), delay);
  }

  async function analyze(tabId) {
    await loadData();
    const s = state(tabId);
    if (!s.page) return;
    const snap = s.page; // a navigation during an await resets s.page: drop this stale run
    if (!(await safe(() => chrome.tabs.get(tabId)))) { tabs.delete(tabId); return; }
    await restoreNet(tabId);
    await Promise.all([collectGlobals(tabId), collectCookies(tabId)]);
    if (s.page !== snap) return;

    const page = {
      url: s.page.url || s.url,
      html: s.page.html, text: s.page.text,
      scriptSrc: s.page.scriptSrc, scripts: s.page.scripts, meta: s.page.meta, dom: s.page.dom,
      headers: s.headers, cookies: s.cookies, js: s.js, jsKeys: s.jsKeys, links: s.page.links || [],
      xhr: [...s.requests, ...s.page.scriptSrc]
    };

    const disabled = new Set(((await safe(() => chrome.storage.sync.get('disabledCats'))) || {}).disabledCats || []);
    if (s.page !== snap) return;

    const detections = Engine.analyze(technologies, page);
    const byName = new Map(detections.map(d => [d.name, d]));
    const ids = Ids.extract(page, new Set(byName.keys()));
    for (const [name, list] of Object.entries(ids)) {
      const tech = technologies[name];
      if (!tech) continue;
      let d = byName.get(name);
      if (!d) {
        d = { name, version: '', confidence: 100, cats: Engine.toArray(tech.cats), icon: tech.icon || null, website: tech.website || null, sources: [], hits: [] };
        byName.set(name, d);
      }
      d.ids = list;
      for (const id of list) if (!d.sources.includes(id.source)) d.sources.push(id.source);
    }

    const list = [...byName.values()].filter(d => !d.cats.every(c => disabled.has(c)));
    s.result = {
      url: page.url,
      title: s.page.title,
      lang: s.page.lang,
      scannedAt: Date.now(),
      detections: list.map(d => ({ name: d.name, version: d.version, confidence: d.confidence, cats: d.cats, icon: d.icon, website: d.website, sources: d.sources, ids: d.ids || [], hits: d.hits.slice(0, 8) })),
      headers: s.headers,
      cookies: s.cookieList || [],
      meta: s.page.meta,
      requestCount: s.requests.length,
      scriptCount: s.page.scriptSrc.length
    };
    setBadge(tabId, list.length);
    saveNet(tabId);
    safe(() => chrome.storage.session.set({ ['tab:' + tabId]: s.result }));
    safe(() => chrome.runtime.sendMessage({ type: 'ti:updated', tabId }));
  }

  function setBadge(tabId, n) {
    safe(() => chrome.action.setBadgeText({ tabId, text: n ? String(n) : '' }));
    safe(() => chrome.action.setBadgeBackgroundColor({ tabId, color: '#C96A00' }));
    safe(() => chrome.action.setBadgeTextColor && chrome.action.setBadgeTextColor({ tabId, color: '#FFFFFF' }));
  }

  // ---------- messages ----------

  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (!msg || !msg.type) return false;
    (async () => {
      switch (msg.type) {
        case 'ti:plan': {
          await loadData();
          reply({ dom: plan.dom });
          return;
        }
        case 'ti:page': {
          const tabId = sender.tab && sender.tab.id;
          if (tabId === undefined || sender.frameId !== 0) { reply({ ok: false }); return; } // top frame only
          const s = state(tabId);
          if (s.url && msg.data.url && s.url.split('#')[0] !== msg.data.url.split('#')[0] && !s.page) s.url = msg.data.url;
          s.page = msg.data;
          await analyze(tabId);
          reply({ ok: true });
          return;
        }
        case 'ti:get': {
          const tabId = msg.tabId;
          let r = tabs.has(tabId) ? tabs.get(tabId).result : null;
          if (!r) { const st = await safe(() => chrome.storage.session.get('tab:' + tabId)); r = st && st['tab:' + tabId]; }
          await loadData();
          reply({ result: r || null, categories, groups, meta });
          return;
        }
        case 'ti:rescan': {
          const tabId = msg.tabId;
          try { await chrome.tabs.sendMessage(tabId, { type: 'ti:collect' }); }
          catch (e) { await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] }).catch(() => {}); }
          reply({ ok: true });
          return;
        }
        case 'ti:catalog': {
          await loadData();
          const list = Object.entries(technologies).map(([name, t]) => [name, Engine.toArray(t.cats), t.icon || null]);
          reply({ list, categories, groups, meta });
          return;
        }
        default: reply(null);
      }
    })().catch(() => { try { reply(null); } catch (e) { /* ignore */ } });
    return true;
  });

  loadData();
})();
