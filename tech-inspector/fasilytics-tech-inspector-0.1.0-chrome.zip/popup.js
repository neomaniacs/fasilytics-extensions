// Tech Inspector — popup.
(function () {
  'use strict';

  const $ = (s) => document.querySelector(s);
  // Any uncaught error shows inside the popup instead of a silent blank box.
  window.addEventListener('error', (e) => { const p = document.getElementById('p-tech'); if (p) p.innerHTML = '<div class="empty">Popup error<small>' + String(e.message || e.error).replace(/[<>&]/g, '') + '</small></div>'; });
  window.addEventListener('unhandledrejection', (e) => { const p = document.getElementById('p-tech'); if (p) p.innerHTML = '<div class="empty">Popup error<small>' + String(e.reason && e.reason.message || e.reason).replace(/[<>&]/g, '') + '</small></div>'; });
  const esc = (s) => String(s === undefined || s === null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const COPY_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>';
  const SRC = [['dom', 'DOM'], ['js', 'JS'], ['xhr', 'NET'], ['cookies', 'CK'], ['headers', 'HDR']];
  const SRC_ALIAS = { scriptSrc: 'dom', scripts: 'dom', meta: 'dom', html: 'dom', text: 'dom', url: 'dom', jsKeys: 'js', implies: null, ids: null, css: 'dom' };

  // Reading order for tag QA. Everything else follows in fingerprint-base priority.
  const CAT_ORDER = ['Ecommerce', 'Ecommerce frontends', 'CMS', 'Page builders', 'Tag managers', 'Analytics', 'Advertising', 'Retargeting', 'Cookie compliance',
    'Customer data platform', 'A/B Testing', 'Personalization', 'Marketing automation', 'Segmentation', 'RUM', 'Browser fingerprinting', 'Email', 'Live chat', 'CRM', 'Reviews',
    'Loyalty & rewards', 'Cart abandonment', 'Payment processors', 'Buy now pay later', 'Security', 'Authentication', 'Maps', 'Video players', 'Widgets',
    'Web frameworks', 'JavaScript frameworks', 'JavaScript libraries', 'UI frameworks', 'JavaScript graphics', 'Font scripts', 'Rich text editors',
    'CDN', 'Performance', 'Caching', 'Web servers', 'Reverse proxies', 'PaaS', 'IaaS', 'Hosting', 'Programming languages', 'Databases', 'Operating systems', 'Miscellaneous'];

  let tabId = null;
  let result = null;
  let categories = {};
  let groups = {};
  let meta = {};
  let catalog = null;
  let catLimit = 120;

  function iconUrl(icon) { return icon ? chrome.runtime.getURL('data/icons/' + icon) : null; }
  function iconHtml(d, cls) {
    const u = iconUrl(d.icon);
    const ini = esc(d.name.replace(/[^A-Za-z0-9 ]/g, '').split(/\s+/).map((w) => w[0]).join('').slice(0, 2).toUpperCase() || '?');
    return u ? `<div class="ico ${cls || ''}"><img src="${u}" alt="" loading="lazy" data-ini="${ini}"></div>` : `<div class="ico ini ${cls || ''}">${ini}</div>`;
  }
  function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('show'), 1400); }
  function copy(v, label) { navigator.clipboard.writeText(v).then(() => toast(label || ('Copied  ' + v))).catch(() => toast('Copy failed')); }
  function send(msg) { return new Promise((res) => { try { chrome.runtime.sendMessage(msg, (r) => res(chrome.runtime.lastError ? null : r)); } catch (e) { res(null); } }); }

  function catName(id) { return (categories[id] && categories[id].name) || ('Category ' + id); }
  function catGroup(id) { const c = categories[id]; if (!c || !c.groups) return ''; return c.groups.map((g) => (groups[g] && groups[g].name) || '').filter(Boolean).join(' / '); }
  function catRank(id) {
    const i = CAT_ORDER.indexOf(catName(id));
    if (i !== -1) return i;
    return 1000 + ((categories[id] && categories[id].priority) || 0);
  }
  function srcSet(d) {
    const s = new Set();
    for (const x of d.sources || []) { const a = x in SRC_ALIAS ? SRC_ALIAS[x] : x; if (a) s.add(a); }
    return s;
  }

  // ---------- header ----------
  function renderHeader() {
    const r = result;
    let host = '—', path = '';
    try { const u = new URL(r.url); host = u.host; path = u.pathname + u.search; } catch (e) { /* ignore */ }
    $('#host').textContent = host;
    $('#path').textContent = path.length > 80 ? path.slice(0, 80) + '…' : path;
    $('#fav').textContent = (host.replace(/^www\./, '')[0] || '?').toUpperCase();
    const ids = r.detections.reduce((n, d) => n + (d.ids || []).length, 0);
    const cats = new Set(r.detections.map((d) => d.cats[0]));
    $('#stats').innerHTML = `<span class="stat"><b>${r.detections.length}</b> technologies</span><span class="stat accent"><b>${ids}</b> IDs found</span><span class="stat"><b>${cats.size}</b> categories</span><span class="stat"><b>${r.cookies.length}</b> cookies</span>`;
    $('#nTech').textContent = r.detections.length;
    $('#nIds').textContent = ids;
    const age = Math.max(0, Math.round((Date.now() - r.scannedAt) / 1000));
    $('#scanTime').textContent = `scanned ${age < 60 ? age + ' s' : Math.round(age / 60) + ' min'} ago · ${r.requestCount} requests`;
  }

  // ---------- technologies ----------
  function flagsFor(d) {
    const flags = [];
    for (const id of d.ids || []) {
      if (id.key === 'endpoint') flags.push({ t: 'server-side endpoint ' + id.value, c: 'warn' });
      if (id.key === 'environment') flags.push({ t: id.value + ' environment', c: /prod/i.test(id.value) ? 'good' : 'warn' });
    }
    if (d.confidence < 50) flags.push({ t: 'low confidence ' + d.confidence + '%', c: 'warn' });
    return flags;
  }

  function renderTech() {
    if (!result) return;
    const q = $('#qTech').value.trim().toLowerCase();
    const only = $('#onlyIds').getAttribute('aria-pressed') === 'true';
    const byCat = new Map();
    for (const d of result.detections) {
      if (only && !(d.ids && d.ids.length)) continue;
      const hay = [d.name, d.version, ...d.cats.map(catName), ...(d.ids || []).map((i) => i.key + ' ' + i.value)].join(' ').toLowerCase();
      if (q && !hay.includes(q)) continue;
      const c = d.cats[0];
      if (!byCat.has(c)) byCat.set(c, []);
      byCat.get(c).push(d);
    }
    const cats = [...byCat.keys()].sort((a, b) => catRank(a) - catRank(b));
    let html = '';
    for (const c of cats) {
      const items = byCat.get(c).sort((a, b) => (b.ids ? b.ids.length : 0) - (a.ids ? a.ids.length : 0) || a.name.localeCompare(b.name));
      html += `<section class="cat"><div class="cat-h"><h3>${esc(catName(c))}</h3><span class="grp">${esc(catGroup(c))}</span><span class="cnt">${items.length}</span></div>`;
      for (const d of items) {
        const s = srcSet(d);
        const ids = (d.ids || []).filter((i) => i.key !== 'endpoint' && i.key !== 'environment');
        html += `<div class="tech">${iconHtml(d)}
          <div class="t-line"><a class="t-name" href="${esc(d.website || '#')}" target="_blank" rel="noopener">${esc(d.name)}</a>${d.version ? `<span class="ver">${esc(d.version)}</span>` : ''}
            ${flagsFor(d).map((f) => `<span class="flag ${f.c}">${esc(f.t)}</span>`).join('')}
            <span class="src">${SRC.map(([k, l]) => `<i class="${s.has(k) ? 'on' : ''}" title="${l}">${l}</i>`).join('')}</span></div>`;
        const hit = (d.hits || []).find((h) => h.source !== 'implies' && h.value && h.value !== d.name);
        if (d.sources.includes('implies') && d.hits.length && d.hits[0].source === 'implies') html += `<div class="t-sub">implied by ${esc(d.hits[0].key)}</div>`;
        else if (hit && hit.key && hit.source !== 'dom') html += `<div class="t-sub" title="${esc(hit.value)}">${esc(hit.source)} · ${esc(hit.key)}</div>`;
        if (ids.length) html += `<div class="ids">${ids.map((i) => `<button class="id" data-v="${esc(i.value)}" title="Copy ${esc(i.key)} (${esc(i.source)})"><span class="k">${esc(i.key)}</span><span class="v">${esc(i.value)}</span>${COPY_SVG}</button>`).join('')}</div>`;
        html += '</div>';
      }
      html += '</section>';
    }
    if (!html) html = result.detections.length ? '<div class="empty">Nothing matches.</div>' : '<div class="empty">No technology detected yet.<small>Reload the page with the extension enabled, then open the popup again.</small></div>';
    html += '<div class="legend"><span><i>DOM</i>markup / scripts</span><span><i>JS</i>window global</span><span><i>NET</i>request fired</span><span><i>CK</i>cookie</span><span><i>HDR</i>response header</span></div>';
    $('#p-tech').innerHTML = html;
  }

  // ---------- ids ----------
  function allIds() {
    const out = [];
    for (const d of result.detections) for (const i of d.ids || []) out.push({ ...i, tech: d });
    return out;
  }
  let idSort = { col: 'vendor', dir: 1 };
  function renderIds() {
    const ids = allIds();
    if (!ids.length) { $('#p-ids').innerHTML = '<div class="empty">No identifier found on this page.</div>'; return; }
    const srcLabel = (x) => { const a = x in SRC_ALIAS ? SRC_ALIAS[x] : x; return (SRC.find(([k]) => k === a) || [null, x])[1]; };
    const get = { vendor: (i) => i.tech.name, key: (i) => i.key, value: (i) => i.value, source: (i) => srcLabel(i.source) }[idSort.col];
    ids.sort((a, b) => get(a).localeCompare(get(b), undefined, { numeric: true, sensitivity: 'base' }) * idSort.dir || a.tech.name.localeCompare(b.tech.name));
    const th = (col, label) => `<th class="sortable ${idSort.col === col ? 'on' : ''}" data-sort="${col}" title="Sort by ${label.toLowerCase()}">${label}<span class="arrow">${idSort.col === col ? (idSort.dir === 1 ? '▲' : '▼') : '▲'}</span></th>`;
    let html = `<table class="idt"><thead><tr>${th('vendor', 'Vendor')}${th('key', 'Key')}${th('value', 'Value')}${th('source', 'Src')}<th></th></tr></thead><tbody>`;
    for (const i of ids) {
      const u = iconUrl(i.tech.icon);
      const sl = srcLabel(i.source);
      const tip = { NET: 'a request carrying this value was fired', JS: 'read from a window global (loaded config)', DOM: 'found in markup or inline script only', CK: 'cookie name', HDR: 'response header' }[sl] || i.source;
      html += `<tr><td><span class="vend">${u ? `<img src="${u}" alt="">` : ''}${esc(i.tech.name)}</span></td><td class="key">${esc(i.key)}</td><td class="mono">${esc(i.value)}</td><td><span class="src"><i class="on" title="${esc(tip)}">${esc(sl)}</i></span></td><td><button class="copyrow" data-v="${esc(i.value)}" title="Copy">${COPY_SVG}</button></td></tr>`;
    }
    $('#p-ids').innerHTML = html + '</tbody></table>';
  }

  // ---------- more info ----------
  function vendorForCookie(name) {
    // Crude attribution: known cookie prefixes -> detected technology names.
    const map = [[/^_ga|^_gid|^_gat/, 'Google Analytics'], [/^_fbp|^_fbc/, 'Facebook Pixel'], [/^_hj/, 'Hotjar'], [/^_cl(ck|sk)/, 'Microsoft Clarity'], [/^dwsid|^dw_|^dwanonymous|^dwac/, 'Salesforce Commerce Cloud'],
      [/^euconsent|^didomi/, 'Didomi'], [/^OptanonConsent|^OptanonAlertBoxClosed/, 'OneTrust'], [/^CookieConsent$/, 'Cookiebot'], [/^axeptio/, 'Axeptio'], [/^TCPID|^TC_|^tc_/, 'Commanders Act TagCommander'],
      [/^cto_/, 'Criteo'], [/^_shopify|^cart|^secure_customer_sig/, 'Shopify'], [/^wordpress|^wp-/, 'WordPress'], [/^_tt_|^_ttp/, 'TikTok Pixel'], [/^_pin_/, 'Pinterest Ads'], [/^li_|^bcookie|^lidc/, 'Linkedin Insight Tag'],
      [/^_uetsid|^_uetvid/, 'Microsoft Advertising'], [/^_gcl_/, 'Google Ads'], [/^__cf|^cf_/, 'Cloudflare'], [/^ak_bmsc|^bm_sv|^_abck|^bm_sz/, 'Akamai'], [/^atid|^atuserid|^pa_/, 'Piano Analytics'], [/^__kla_/, 'Klaviyo'], [/^mp_/, 'Mixpanel'], [/^amp_/, 'Amplitude'], [/^ajs_/, 'Segment'], [/^intercom/, 'Intercom'], [/^__zlcmid|^_zendesk/, 'Zendesk'], [/^_pk_|^MATOMO/, 'Matomo Analytics'], [/^_ym_/, 'Yandex.Metrika'], [/^__utm/, 'Google Analytics']];
    for (const [rx, name] of map) if (rx.test(name)) return name;
    return null;
  }
  function ttl(c) {
    if (c.session || !c.expires) return 'session';
    const days = (c.expires * 1000 - Date.now()) / 86400000;
    if (days < 1) return '< 1 day';
    if (days < 60) return Math.round(days) + ' d';
    if (days < 400) return Math.round(days / 30) + ' mo';
    return (days / 365).toFixed(1) + ' y';
  }
  function renderInfo() {
    const r = result;
    const m = r.meta || {};
    const first = (k) => (m[k] && m[k][0]) || '';
    let html = `<div class="section"><h3>Page</h3><dl class="kv">
      <dt>Title</dt><dd>${esc(r.title)}</dd>
      <dt>Language</dt><dd>${esc(r.lang || '—')}</dd>
      <dt>Generator</dt><dd>${esc(first('generator') || '—')}</dd>
      <dt>Description</dt><dd>${esc((first('description') || '—').slice(0, 200))}</dd>
      <dt>og:site_name</dt><dd>${esc(first('og:site_name') || '—')}</dd>
      <dt>Scripts</dt><dd>${r.scriptCount} external · ${r.requestCount} requests seen</dd></dl></div>`;
    const H = Object.entries(r.headers || {}).sort((a, b) => a[0].localeCompare(b[0]));
    html += `<div class="section"><h3>Response headers <span class="cnt">${H.length}</span></h3><dl class="kv">${H.map(([k, v]) => `<dt title="${esc(k)}">${esc(k)}</dt><dd>${esc(v.join(' | ').slice(0, 300))}</dd>`).join('') || '<dt>—</dt><dd>not captured (reload the page)</dd>'}</dl></div>`;
    const byName = new Map(r.detections.map((d) => [d.name, d]));
    const C = [...r.cookies].sort((a, b) => a.name.localeCompare(b.name));
    html += `<div class="section"><h3>Cookies <span class="cnt">${C.length}</span></h3>${C.map((c) => {
      const v = vendorForCookie(c.name); const d = v && byName.get(v); const u = d && iconUrl(d.icon);
      return `<div class="ck"><span class="n" title="${esc(c.domain)}">${esc(c.name)}</span><span class="who">${u ? `<img src="${u}" alt="">` : ''}${esc(v || c.domain)}</span><span class="ttl">${ttl(c)}</span></div>`;
    }).join('') || '<div class="empty">No cookie.</div>'}</div>`;
    html += `<div class="section"><h3>Fingerprint base</h3><dl class="kv"><dt>Source</dt><dd>enthec/webappanalyzer (GPL-3.0)</dd><dt>Commit</dt><dd>${esc(meta.commit || '?')} · ${esc((meta.commitDate || '').slice(0, 10))}</dd><dt>Technologies</dt><dd>${esc(meta.count || '?')}</dd></dl></div>`;
    $('#p-info').innerHTML = html;
  }

  // ---------- catalog ----------
  async function ensureCatalog() {
    if (catalog) return;
    const r = await send({ type: 'ti:catalog' });
    catalog = (r && r.list) || [];
    $('#nCat').textContent = catalog.length.toLocaleString('en-US');
    const counts = {};
    for (const t of catalog) for (const c of t[1]) counts[c] = (counts[c] || 0) + 1;
    const sel = $('#selCat');
    Object.entries(categories).sort((a, b) => (counts[b[0]] || 0) - (counts[a[0]] || 0)).forEach(([id, c]) => {
      const o = document.createElement('option'); o.value = id; o.textContent = `${c.name} (${counts[id] || 0})`; sel.appendChild(o);
    });
  }
  function renderCatalog() {
    if (!catalog) return;
    const q = $('#qCat').value.trim().toLowerCase();
    const c = $('#selCat').value ? Number($('#selCat').value) : null;
    const rows = catalog.filter((t) => (c === null || t[1].includes(c)) && (!q || t[0].toLowerCase().includes(q)));
    let html = `<div class="section"><h3>${rows.length.toLocaleString('en-US')} technologies${c !== null ? ' in ' + esc(catName(c)) : ''}<span class="cnt">base ${esc(meta.commit || '')}</span></h3><div class="cat-list">`;
    for (const t of rows.slice(0, catLimit)) {
      html += `<div class="cat-row">${iconHtml({ name: t[0], icon: t[2] })}<span class="nm">${esc(t[0])}</span><span class="cc">${t[1].map((x) => `<span>${esc(catName(x))}</span>`).join('')}</span></div>`;
    }
    html += '</div>';
    if (rows.length > catLimit) html += `<button class="more" id="moreCat">Show ${Math.min(200, rows.length - catLimit)} more</button>`;
    $('#p-catalog').innerHTML = html + '</div>';
  }

  // ---------- export ----------
  function download(name, text, type) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type }));
    a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  function hostSlug() { try { return new URL(result.url).host.replace(/[^a-z0-9.-]/gi, '_'); } catch (e) { return 'page'; } }
  function doExport(kind) {
    if (!result) return;
    if (kind === 'json') {
      const out = { url: result.url, scannedAt: new Date(result.scannedAt).toISOString(), technologies: result.detections.map((d) => ({ name: d.name, version: d.version || null, confidence: d.confidence, categories: d.cats.map(catName), website: d.website, sources: d.sources, ids: d.ids || [] })), headers: result.headers, cookies: result.cookies };
      download(`tech-inspector_${hostSlug()}.json`, JSON.stringify(out, null, 2), 'application/json');
    } else if (kind === 'csv') {
      const rows = [['technology', 'category', 'version', 'key', 'value', 'source']];
      for (const d of result.detections) {
        if (!d.ids || !d.ids.length) rows.push([d.name, catName(d.cats[0]), d.version || '', '', '', d.sources.join('+')]);
        for (const i of d.ids || []) rows.push([d.name, catName(d.cats[0]), d.version || '', i.key, i.value, i.source]);
      }
      download(`tech-inspector_${hostSlug()}.csv`, rows.map((r) => r.map((x) => '"' + String(x).replace(/"/g, '""') + '"').join(',')).join('\n'), 'text/csv');
    } else {
      const lines = [result.url, ''];
      for (const d of result.detections) lines.push(`${d.name}${d.version ? ' ' + d.version : ''}${d.ids && d.ids.length ? ' — ' + d.ids.map((i) => i.key + ': ' + i.value).join(', ') : ''}`);
      copy(lines.join('\n'), `Copied ${result.detections.length} technologies`);
    }
    $('#exportMenu').hidden = true;
  }

  // ---------- wiring ----------
  document.querySelectorAll('.tab').forEach((b) => b.addEventListener('click', async () => {
    document.querySelectorAll('.tab').forEach((x) => x.setAttribute('aria-selected', x === b ? 'true' : 'false'));
    const id = b.dataset.tab;
    ['tech', 'ids', 'info', 'catalog'].forEach((k) => { $('#p-' + k).hidden = k !== id; const tb = $('#tb-' + k); if (tb) tb.hidden = k !== id; });
    $('.body').scrollTop = 0;
    if (id === 'catalog') { await ensureCatalog(); renderCatalog(); }
  }));
  $('#qTech').addEventListener('input', renderTech);
  $('#onlyIds').addEventListener('click', (e) => { const b = e.currentTarget; b.setAttribute('aria-pressed', b.getAttribute('aria-pressed') === 'true' ? 'false' : 'true'); renderTech(); });
  $('#qCat').addEventListener('input', () => { catLimit = 120; renderCatalog(); });
  $('#selCat').addEventListener('change', () => { catLimit = 120; renderCatalog(); });
  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-v]'); if (b) { copy(b.dataset.v); return; }
    const th = e.target.closest('th[data-sort]'); if (th) { const col = th.dataset.sort; idSort = { col, dir: idSort.col === col ? -idSort.dir : 1 }; renderIds(); return; }
    if (e.target.id === 'moreCat') { catLimit += 200; renderCatalog(); return; }
    const ex = e.target.closest('[data-export]'); if (ex) { doExport(ex.dataset.export); return; }
    if (!e.target.closest('#exportMenu') && !e.target.closest('#exportBtn')) $('#exportMenu').hidden = true;
  });
  document.addEventListener('error', (e) => {
    // Broken icon file -> initials tile.
    const img = e.target; if (!(img instanceof HTMLImageElement) || !img.dataset.ini) return;
    const box = img.parentElement; box.classList.add('ini'); box.textContent = img.dataset.ini;
  }, true);
  $('#copyAll').addEventListener('click', () => { const ids = allIds(); copy(ids.map((i) => `${i.tech.name}\t${i.key}\t${i.value}`).join('\n'), `Copied ${ids.length} IDs as TSV`); });
  $('#exportBtn').addEventListener('click', () => { $('#exportMenu').hidden = !$('#exportMenu').hidden; });
  $('#optionsBtn').addEventListener('click', () => chrome.runtime.openOptionsPage());
  $('#rescanBtn').addEventListener('click', async () => { toast('Rescanning…'); await send({ type: 'ti:rescan', tabId }); setTimeout(load, 1500); });
  $('#themeBtn').addEventListener('click', () => {
    const r = document.documentElement; const cur = r.getAttribute('data-theme');
    const isDark = cur ? cur === 'dark' : matchMedia('(prefers-color-scheme: dark)').matches;
    const next = isDark ? 'light' : 'dark';
    r.setAttribute('data-theme', next);
    chrome.storage.sync.set({ theme: next });
  });
  chrome.runtime.onMessage.addListener((msg) => { if (msg && msg.type === 'ti:updated' && msg.tabId === tabId) load(); });

  async function load() {
    const r = await send({ type: 'ti:get', tabId });
    if (!r) { $('#p-tech').innerHTML = '<div class="empty">Background not reachable.<small>Reload the extension.</small></div>'; return; }
    categories = r.categories || {}; groups = r.groups || {}; meta = r.meta || {};
    $('#ver').textContent = 'Tech Inspector ' + chrome.runtime.getManifest().version;
    if (!r.result) {
      $('#p-tech').innerHTML = '<div class="empty">No scan for this tab yet.<small>Reload the page, or click rescan.</small></div>';
      $('#stats').innerHTML = '';
      return;
    }
    result = r.result;
    renderHeader(); renderTech(); renderIds(); renderInfo();
    if (catalog) renderCatalog();
  }

  (async () => {
    const st = await new Promise((res) => chrome.storage.sync.get('theme', res));
    if (st && st.theme) document.documentElement.setAttribute('data-theme', st.theme);
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    tabId = tabs && tabs[0] ? tabs[0].id : null;
    if (tabs && tabs[0] && tabs[0].favIconUrl) $('#fav').innerHTML = `<img src="${esc(tabs[0].favIconUrl)}" alt="">`;
    await load();
    ensureCatalog();
  })();
})();
