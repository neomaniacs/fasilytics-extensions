// Chrome MV3 service worker entry. The Firefox build (scripts/build-firefox.js)
// replaces this with background.scripts listing the same files in this order.
importScripts('engine.js', 'ids.js', 'background.js');
