// Tech Inspector — detection engine.
//
// Consumes the Wappalyzer / webappanalyzer fingerprint schema unchanged
// (js, scriptSrc, scripts, dom, meta, headers, cookies, xhr, url, html, text,
// implies, requires, requiresCategory, excludes, "\;version:" and
// "\;confidence:" directives) and adds nothing to the data format. Identifier
// extraction lives in ids.js and runs on the same collected page data.
//
// Works in a service worker, a background script and Node (test/sanity.js).

(function (root) {
  'use strict';

  // ---------- pattern parsing ----------

  const patternCache = new Map();

  function toArray(v) { return v === undefined || v === null ? [] : Array.isArray(v) ? v : [v]; }

  // "regex\;version:\1\;confidence:50" -> { regex, version, confidence }
  function parsePattern(str) {
    if (typeof str !== 'string') str = String(str);
    let p = patternCache.get(str);
    if (p) return p;
    const parts = str.split('\\;');
    let regex;
    try {
      regex = new RegExp(parts[0].replace(/\//g, '\\/'), 'i');
    } catch (e) {
      regex = /(?!)/; // never matches
    }
    p = { source: parts[0], regex, version: '', confidence: 100 };
    for (const attr of parts.slice(1)) {
      const i = attr.indexOf(':');
      const k = i === -1 ? attr : attr.slice(0, i);
      const v = i === -1 ? '' : attr.slice(i + 1);
      if (k === 'version') p.version = v;
      else if (k === 'confidence') p.confidence = Number(v) || 0;
    }
    patternCache.set(str, p);
    return p;
  }

  function parsePatterns(value) {
    // string | string[] | { key: string | string[] }
    if (value === undefined || value === null) return [];
    if (typeof value === 'string' || Array.isArray(value)) return toArray(value).map(parsePattern);
    const out = {};
    for (const [k, v] of Object.entries(value)) out[k] = toArray(v).map(parsePattern);
    return out;
  }

  // Wappalyzer's version resolution: "\1" substitution, "\1?a:b" ternary.
  function resolveVersion(pattern, text) {
    let resolved = pattern.version;
    if (!resolved) return '';
    const m = pattern.regex.exec(text);
    if (!m) return '';
    m.forEach((group, i) => {
      const ternary = new RegExp('\\\\' + i + '\\?([^:]+):(.*)$').exec(resolved);
      if (ternary && ternary.length === 3) {
        resolved = resolved.replace(ternary[0], group ? ternary[1] : ternary[2]);
      }
      resolved = resolved.trim().replace(new RegExp('\\\\' + i, 'g'), group || '');
    });
    return resolved.trim();
  }

  // ---------- matching helpers ----------

  function matchList(patterns, values, source) {
    const hits = [];
    for (const p of patterns) {
      for (const value of values) {
        if (typeof value !== 'string') continue;
        if (p.regex.test(value)) {
          hits.push({ source, pattern: p, value, version: resolveVersion(p, value), confidence: p.confidence });
          break; // one hit per pattern is enough for confidence
        }
      }
    }
    return hits;
  }

  function matchKeyed(patternsByKey, valuesByKey, source, opts) {
    // patternsByKey: { key: [pattern] }, valuesByKey: { key: string | string[] }
    const hits = [];
    const lowerMap = opts && opts.caseInsensitiveKeys ? lowerKeys(valuesByKey) : null;
    for (const [key, patterns] of Object.entries(patternsByKey)) {
      let values;
      if (key.includes('*') && !lowerMap) {
        const rx = new RegExp('^' + key.split('*').map(escapeRegex).join('.*') + '$', 'i');
        values = [];
        for (const [k, v] of Object.entries(valuesByKey)) if (rx.test(k)) values.push(...toArray(v));
      } else {
        values = toArray(lowerMap ? lowerMap[key.toLowerCase()] : valuesByKey[key]);
      }
      if (!values.length) continue;
      for (const p of patterns) {
        if (!p.source) { // empty pattern: presence is enough, version may still be a literal ("\;version:GA4")
          hits.push({ source, key, pattern: p, value: values[0], version: resolveVersion(p, String(values[0])), confidence: p.confidence });
          continue;
        }
        for (const value of values) {
          if (typeof value !== 'string') continue;
          if (p.regex.test(value)) {
            hits.push({ source, key, pattern: p, value, version: resolveVersion(p, value), confidence: p.confidence });
            break;
          }
        }
      }
    }
    return hits;
  }

  function lowerKeys(o) { const r = {}; for (const [k, v] of Object.entries(o || {})) r[k.toLowerCase()] = v; return r; }
  function escapeRegex(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

  // dom: "selector" | ["sel", ...] | { selector: { exists, text, attributes:{}, properties:{} } }
  // page.dom is produced by the content script as { selector: [ { text, attributes:{}, properties:{} } ] }
  function matchDom(domSpec, domResults) {
    const hits = [];
    if (!domResults) return hits;
    if (typeof domSpec === 'string' || Array.isArray(domSpec)) {
      for (const sel of toArray(domSpec)) {
        const nodes = domResults[sel];
        if (nodes && nodes.length) hits.push({ source: 'dom', key: sel, pattern: parsePattern(''), value: sel, version: '', confidence: 100 });
      }
      return hits;
    }
    for (const [sel, spec] of Object.entries(domSpec)) {
      const nodes = domResults[sel];
      if (!nodes || !nodes.length) continue;
      if (spec.exists !== undefined) {
        const p = parsePattern(spec.exists);
        hits.push({ source: 'dom', key: sel, pattern: p, value: sel, version: resolveVersion(p, sel), confidence: p.confidence });
      }
      if (spec.text !== undefined) {
        hits.push(...matchList(toArray(spec.text).map(parsePattern), nodes.map(n => n.text || ''), 'dom').map(h => ({ ...h, key: sel })));
      }
      if (spec.attributes) {
        for (const [attr, pat] of Object.entries(spec.attributes)) {
          const patterns = toArray(pat).map(parsePattern);
          const values = nodes.map(n => (n.attributes || {})[attr]).filter(v => v !== undefined && v !== null);
          for (const p of patterns) {
            if (!p.source) { if (values.length) hits.push({ source: 'dom', key: sel + '[' + attr + ']', pattern: p, value: values[0], version: '', confidence: p.confidence }); continue; }
            const v = values.find(x => p.regex.test(x));
            if (v !== undefined) hits.push({ source: 'dom', key: sel + '[' + attr + ']', pattern: p, value: v, version: resolveVersion(p, v), confidence: p.confidence });
          }
        }
      }
      if (spec.properties) {
        for (const [prop, pat] of Object.entries(spec.properties)) {
          const patterns = toArray(pat).map(parsePattern);
          const values = nodes.map(n => (n.properties || {})[prop]).filter(v => v !== undefined && v !== null).map(String);
          for (const p of patterns) {
            if (!p.source) { if (values.length) hits.push({ source: 'dom', key: sel + '.' + prop, pattern: p, value: values[0], version: '', confidence: p.confidence }); continue; }
            const v = values.find(x => p.regex.test(x));
            if (v !== undefined) hits.push({ source: 'dom', key: sel + '.' + prop, pattern: p, value: v, version: resolveVersion(p, v), confidence: p.confidence });
          }
        }
      }
    }
    return hits;
  }

  // ---------- analysis ----------

  /**
   * page = {
   *   url, html, text,
   *   scriptSrc: [], scripts: [] (inline text), css: [],
   *   meta: { name: [content] }, headers: { lowername: [value] },
   *   cookies: { name: value }, js: { 'path.to.global': value },
   *   dom: { selector: [ { text, attributes, properties } ] },
   *   xhr: [] (request URLs, hostnames matched)
   * }
   * Returns [{ name, version, confidence, hits: [...] }]
   */
  function analyze(technologies, page) {
    const found = new Map();

    for (const [name, tech] of Object.entries(technologies)) {
      const hits = [];
      if (tech.url) hits.push(...matchList(parsePatterns(tech.url), [page.url || ''], 'url'));
      if (tech.html && page.html) hits.push(...matchList(parsePatterns(tech.html), [page.html], 'html'));
      if (tech.text && page.text) hits.push(...matchList(parsePatterns(tech.text), [page.text], 'text'));
      if (tech.css && page.css) hits.push(...matchList(parsePatterns(tech.css), page.css, 'css'));
      if (tech.scriptSrc && page.scriptSrc) hits.push(...matchList(parsePatterns(tech.scriptSrc), page.scriptSrc, 'scriptSrc'));
      if (tech.scripts && page.scripts) hits.push(...matchList(parsePatterns(tech.scripts), page.scripts, 'scripts'));
      if (tech.xhr && page.xhr) hits.push(...matchList(parsePatterns(tech.xhr), page.xhr, 'xhr'));
      if (tech.meta && page.meta) hits.push(...matchKeyed(parsePatterns(tech.meta), page.meta, 'meta', { caseInsensitiveKeys: true }));
      if (tech.headers && page.headers) hits.push(...matchKeyed(parsePatterns(tech.headers), page.headers, 'headers', { caseInsensitiveKeys: true }));
      if (tech.cookies && page.cookies) hits.push(...matchKeyed(parsePatterns(tech.cookies), page.cookies, 'cookies'));
      if (tech.js && page.js) hits.push(...matchKeyed(parsePatterns(tech.js), page.js, 'js'));
      if (tech.dom && page.dom) hits.push(...matchDom(tech.dom, page.dom));
      if (hits.length) found.set(name, { name, hits });
    }

    // implies (may carry \;confidence:)
    let added = true;
    while (added) {
      added = false;
      for (const det of [...found.values()]) {
        const tech = technologies[det.name];
        for (const imp of toArray(tech.implies)) {
          const p = parsePattern(imp);
          const implied = p.source;
          if (!technologies[implied] || found.has(implied)) continue;
          found.set(implied, { name: implied, hits: [{ source: 'implies', key: det.name, pattern: p, value: det.name, version: '', confidence: p.confidence }] });
          added = true;
        }
      }
    }

    // requires / requiresCategory / excludes
    for (const det of [...found.values()]) {
      const tech = technologies[det.name];
      const req = toArray(tech.requires).map(r => parsePattern(r).source);
      if (req.length && !req.every(r => found.has(r))) { found.delete(det.name); continue; }
      const reqCat = toArray(tech.requiresCategory).map(Number);
      if (reqCat.length && !reqCat.every(c => [...found.values()].some(d => d.name !== det.name && toArray(technologies[d.name].cats).includes(c)))) { found.delete(det.name); continue; }
    }
    for (const det of [...found.values()]) {
      for (const ex of toArray(technologies[det.name].excludes)) found.delete(parsePattern(ex).source);
    }

    // finalize
    const out = [];
    for (const det of found.values()) {
      const tech = technologies[det.name];
      let confidence = 0;
      let version = '';
      const sources = new Set();
      for (const h of det.hits) {
        confidence = Math.min(100, confidence + h.confidence);
        if (h.version && (!version || h.version.length > version.length)) version = h.version;
        sources.add(h.source);
      }
      out.push({
        name: det.name,
        version,
        confidence,
        cats: toArray(tech.cats),
        icon: tech.icon || null,
        website: tech.website || null,
        sources: [...sources],
        hits: det.hits.map(h => ({ source: h.source, key: h.key, value: h.value, confidence: h.confidence, version: h.version }))
      });
    }
    return out.sort((a, b) => a.name.localeCompare(b.name));
  }

  // Which JS global paths and DOM selectors the content script must collect.
  function collectionPlan(technologies) {
    const js = new Set();
    const dom = new Set();
    for (const tech of Object.values(technologies)) {
      if (tech.js) for (const k of Object.keys(tech.js)) js.add(k);
      if (tech.dom) {
        if (typeof tech.dom === 'string' || Array.isArray(tech.dom)) toArray(tech.dom).forEach(s => dom.add(s));
        else Object.keys(tech.dom).forEach(s => dom.add(s));
      }
    }
    return { js: [...js], dom: [...dom] };
  }

  const api = { parsePattern, parsePatterns, resolveVersion, analyze, collectionPlan, toArray };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.TechEngine = api;
})(typeof self !== 'undefined' ? self : globalThis);
