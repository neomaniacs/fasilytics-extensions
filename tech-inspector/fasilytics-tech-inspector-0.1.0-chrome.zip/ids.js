// Tech Inspector — identifier extraction layer.
//
// The fingerprint base says WHICH technology is on the page. This file says
// WHICH ACCOUNT of it: container IDs, property IDs, pixel IDs, site keys,
// shop domains. Rules are keyed by the technology name used in
// data/technologies.json (webappanalyzer naming).
//
// Rule shape:
//   { key: 'container', from: <source>, regex: /.../ , path|selector|attr|name }
//   from = scriptSrc | requests | scripts | html | links | js | jsKeys | dom | meta | headers | cookies | url
//   filter: optional regex a value must match before `regex` is applied
//   prefix: prepended to the captured value when missing (AW-, DC-) so the
//           same account seen through two URL shapes dedupes to one chip
//   weak:   generic regex; attaches to a detected technology but never
//           creates the detection on its own
//   regex: group 1 = value (group 2+ appended with " · " when present)
//   jsKeys: the keys of the object found at `path` (e.g. google_tag_manager)
//   js:     the stringified value found at `path`
//   dom:    attribute `attr` of every node matching `selector`
//
// A matched rule for a technology the engine did not detect still creates
// the detection (source "ids"), because an identifier is stronger evidence
// than a pattern.

(function (root) {
  'use strict';

  const GTM_KEYS = { path: 'google_tag_manager' };

  const RULES = {
    // ---------- Google ----------
    'Google Tag Manager': [
      { key: 'container', from: 'jsKeys', ...GTM_KEYS, regex: /^(GTM-[A-Z0-9]+)$/ },
      { key: 'container', from: 'scriptSrc', regex: /[?&]id=(GTM-[A-Z0-9]+)/i },
      { key: 'container', from: 'requests', regex: /gtm\.js\?(?:[^#]*&)?id=(GTM-[A-Z0-9]+)/i },
      { key: 'container', from: 'scripts', regex: /['"](GTM-[A-Z0-9]{4,})['"]/ }
    ],
    'Google Analytics': [
      { key: 'property', from: 'jsKeys', ...GTM_KEYS, regex: /^(G-[A-Z0-9]+)$/ },
      { key: 'property', from: 'requests', regex: /[?&]tid=(G-[A-Z0-9]+)/ },
      { key: 'property', from: 'scriptSrc', regex: /gtag\/js\?(?:[^#]*&)?id=(G-[A-Z0-9]+)/ },
      { key: 'property', from: 'scripts', regex: /['"](G-[A-Z0-9]{6,})['"]/ },
      { key: 'ua property', from: 'requests', regex: /[?&]tid=(UA-\d+-\d+)/ },
      { key: 'ua property', from: 'scripts', regex: /['"](UA-\d{4,}-\d+)['"]/ },
      { key: 'ua property', from: 'jsKeys', ...GTM_KEYS, regex: /^(UA-\d+-\d+)$/ },
      { key: 'endpoint', from: 'requests', regex: /^https?:\/\/((?![^/]*(?:google-analytics\.com|analytics\.google\.com|googletagmanager\.com|doubleclick\.net|google\.com))[^/]+)\/g\/collect\?/ }
    ],
    // The AW- account belongs to one technology only, otherwise the IDs tab
    // shows the same value twice ("Google Ads" is the ad-serving side).
    'Google Ads Conversion Tracking': [
      { key: 'account', from: 'jsKeys', ...GTM_KEYS, regex: /^(AW-\d+)$/ },
      { key: 'account', from: 'requests', regex: /[?&]tid=(AW-\d+)/ },
      { key: 'account', from: 'requests', regex: /viewthroughconversion\/(\d+)/, prefix: 'AW-' },
      { key: 'account', from: 'requests', regex: /pagead\/(?:1p-)?conversion\/(\d+)/, prefix: 'AW-' },
      { key: 'account', from: 'scripts', regex: /['"](AW-\d{6,})['"]/ },
      { key: 'label', from: 'requests', regex: /[?&]label=([A-Za-z0-9_-]{8,})/, weak: true }
    ],
    'DoubleClick Floodlight': [
      { key: 'advertiser', from: 'jsKeys', ...GTM_KEYS, regex: /^(DC-\d+)$/ },
      { key: 'advertiser', from: 'requests', regex: /[?&]tid=(DC-\d+)/ },
      // src= in a Floodlight hit is the advertiser id, same number as DC-xxx.
      { key: 'advertiser', from: 'requests', regex: /doubleclick\.net\/(?:activity|ddm\/activity)[^ ]*?[;/]src=(\d+)/, prefix: 'DC-' },
      { key: 'advertiser', from: 'requests', regex: /fls\.doubleclick\.net\/activityi;src=(\d+)/, prefix: 'DC-' },
      { key: 'activity', from: 'requests', regex: /doubleclick\.net\/(?:activity|ddm\/activity|activityi)[^ ]*?;type=([A-Za-z0-9_-]+);cat=([A-Za-z0-9_-]+)/, weak: true }
    ],
    'Google AdSense': [
      { key: 'publisher', from: 'scriptSrc', regex: /[?&]client=(ca-pub-\d+)/ },
      { key: 'publisher', from: 'scripts', regex: /(ca-pub-\d{10,})/ },
      { key: 'publisher', from: 'requests', regex: /[?&]client=(ca-pub-\d+)/ }
    ],
    'Google Publisher Tag': [
      { key: 'network', from: 'requests', regex: /gampad\/ads\?(?:[^#]*&)?iu=\/(\d+)\// },
      { key: 'ad unit', from: 'requests', regex: /gampad\/ads\?(?:[^#]*&)?iu=(\/\d+\/[^&]+)/ },
      { key: 'network', from: 'scripts', regex: /defineSlot\(\s*['"]\/(\d+)\// }
    ],
    'reCAPTCHA': [
      { key: 'site key', from: 'scriptSrc', regex: /recaptcha\/(?:api|enterprise)\.js\?(?:[^#]*&)?render=([A-Za-z0-9_-]{30,})/ },
      { key: 'site key', from: 'dom', selector: '.g-recaptcha[data-sitekey]', attr: 'data-sitekey' },
      { key: 'site key', from: 'scripts', regex: /sitekey['"]?\s*[:=]\s*['"]([A-Za-z0-9_-]{30,})/, weak: true },
      { key: 'site key', from: 'requests', regex: /recaptcha\/(?:api2|enterprise)\/anchor\?(?:[^#]*&)?k=([A-Za-z0-9_-]{30,})/ }
    ],
    'hCaptcha': [
      { key: 'site key', from: 'dom', selector: '.h-captcha[data-sitekey]', attr: 'data-sitekey' },
      { key: 'site key', from: 'requests', regex: /hcaptcha\.com\/(?:1\/)?api\.js\?(?:[^#]*&)?sitekey=([a-f0-9-]{36})/ }
    ],
    'Google Maps': [
      { key: 'api key', from: 'scriptSrc', regex: /maps\.googleapis\.com\/maps\/api\/js\?(?:[^#]*&)?key=([A-Za-z0-9_-]{20,})/ }
    ],
    // ---------- Pixels / ads ----------
    'Facebook Pixel': [
      { key: 'pixel', from: 'requests', regex: /facebook\.com\/tr\/?\?(?:[^#]*&)?id=(\d{6,})/ },
      { key: 'pixel', from: 'scriptSrc', regex: /signals\/config\/(\d{6,})/ },
      { key: 'pixel', from: 'scripts', regex: /fbq\(\s*['"]init['"]\s*,\s*['"](\d{6,})['"]/ },
      { key: 'pixel', from: 'jsKeys', path: 'fbq.instance.pixelsByID', regex: /^(\d{6,})$/ }
    ],
    'TikTok Pixel': [
      { key: 'pixel', from: 'jsKeys', path: 'ttq._i', regex: /^([A-Z0-9]{16,})$/ },
      { key: 'pixel', from: 'scriptSrc', regex: /analytics\.tiktok\.com\/i18n\/pixel\/events\.js\?(?:[^#]*&)?sdkid=([A-Z0-9]+)/ },
      { key: 'pixel', from: 'requests', regex: /[?&](?:sdkid|pixel_code)=([A-Z0-9]{16,})/ },
      { key: 'pixel', from: 'scripts', regex: /ttq\.load\(\s*['"]([A-Z0-9]{16,})['"]/ }
    ],
    'Pinterest Conversion Tag': [
      { key: 'tag', from: 'requests', regex: /ct\.pinterest\.com\/v3\/?\?(?:[^#]*&)?tid=(\d+)/ },
      { key: 'tag', from: 'scripts', regex: /pintrk\(\s*['"]load['"]\s*,\s*['"](\d{10,})['"]/ }
    ],
    'Linkedin Insight Tag': [
      { key: 'partner', from: 'js', path: '_linkedin_data_partner_ids', regex: /(\d{5,})/g },
      { key: 'partner', from: 'js', path: '_linkedin_partner_id', regex: /^(\d{5,})$/ },
      { key: 'partner', from: 'requests', regex: /px\.ads\.linkedin\.com\/collect\/?\?(?:[^#]*&)?pid=(\d+)/ }
    ],
    'Snap Pixel': [
      { key: 'pixel', from: 'js', path: 'snaptr.pixelIdList', regex: /([a-f0-9-]{36})/g },
      { key: 'pixel', from: 'scripts', regex: /snaptr\(\s*['"]init['"]\s*,\s*['"]([a-f0-9-]{36})['"]/ },
      { key: 'pixel', from: 'requests', regex: /tr\.snapchat\.com\/[^?]*\?(?:[^#]*&)?pid=([a-f0-9-]{36})/ }
    ],
    'Twitter Ads': [
      { key: 'pixel', from: 'scripts', regex: /twq\(\s*['"](?:config|init)['"]\s*,\s*['"]([a-z0-9]{5,})['"]/ },
      { key: 'pixel', from: 'requests', regex: /(?:analytics\.twitter\.com|t\.co)\/i\/adsct\?(?:[^#]*&)?txn_id=([a-z0-9]+)/ }
    ],
    'Criteo': [
      { key: 'account', from: 'requests', regex: /criteo\.(?:com|net)\/[^?]*\?(?:[^#]*&)?a=(\d+)/ },
      { key: 'account', from: 'scriptSrc', regex: /criteo\.net\/js\/ld\/ld\.js\?(?:[^#]*&)?a=(\d+)/ },
      { key: 'account', from: 'scripts', regex: /event\s*:\s*['"]setAccount['"]\s*,\s*account\s*:\s*(\d+)/ }
    ],
    'Microsoft Advertising': [
      { key: 'uet tag', from: 'scripts', regex: /\bti\s*:\s*['"]?(\d{6,})['"]?/, weak: true },
      { key: 'uet tag', from: 'requests', regex: /bat\.bing\.com\/(?:action|p)\/[^?]*\?(?:[^#]*&)?ti=(\d+)/ }
    ],
    'Yandex.Metrika': [
      { key: 'counter', from: 'scripts', regex: /ym\(\s*(\d{5,})\s*,\s*['"]init['"]/ },
      { key: 'counter', from: 'requests', regex: /mc\.yandex\.(?:ru|com)\/watch\/(\d+)/ }
    ],
    'Outbrain': [{ key: 'ob key', from: 'scripts', regex: /OB_ADV_ID\s*[:=]\s*['"]?([A-Za-z0-9]{6,})/ }],
    'Taboola': [{ key: 'account', from: 'scriptSrc', regex: /cdn\.taboola\.com\/libtrc\/([a-z0-9-]+)\/loader\.js/i }],
    'Amazon Advertising': [{ key: 'tag', from: 'requests', regex: /amazon-adsystem\.com\/[^?]*\?(?:[^#]*&)?(?:tag|pid)=([A-Za-z0-9_-]+)/ }],
    // ---------- Analytics ----------
    'Hotjar': [
      { key: 'site', from: 'js', path: '_hjSettings.hjid', regex: /^(\d+)$/ },
      { key: 'site', from: 'scriptSrc', regex: /static\.hotjar\.com\/c\/hotjar-(\d+)\.js/ },
      { key: 'site', from: 'cookies', regex: /^_hjSessionUser_(\d+)$/ }
    ],
    'Microsoft Clarity': [
      { key: 'project', from: 'scriptSrc', regex: /clarity\.ms\/tag\/([a-z0-9]{6,})/ },
      { key: 'project', from: 'scripts', regex: /clarity\.ms\/tag\/['"]?\s*\+?\s*['"]?([a-z0-9]{6,})/ },
      { key: 'project', from: 'scripts', regex: /['"]clarity['"]\s*,\s*['"]script['"]\s*,\s*['"]([a-z0-9]{6,})['"]/ }
    ],
    'Piano Analytics': [
      { key: 'site', from: 'requests', regex: /\.(?:xiti\.com|piano\.io|pa-cd\.com)\/[^?]*\?(?:[^#]*&)?s=(\d+)/ },
      { key: 'site', from: 'scriptSrc', regex: /tag\.aticdn\.net\/(\d+)\/smarttag\.js/ },
      { key: 'site', from: 'scripts', regex: /site\s*:\s*['"]?(\d{4,})['"]?/, weak: true },
      { key: 'collect', from: 'requests', regex: /^https?:\/\/((?:logs?\d*|logc\d*)\.xiti\.com)\// },
      { key: 'collect', from: 'requests', regex: /^https?:\/\/([a-z0-9.-]+\.pa-cd\.com)\// }
    ],
    'Adobe Analytics': [
      { key: 'report suite', from: 'requests', regex: /\/b\/ss\/([^/]+)\// },
      { key: 'report suite', from: 'js', path: 's.account', regex: /^([A-Za-z0-9,_-]+)$/ },
      { key: 'tracking server', from: 'requests', regex: /^https?:\/\/([^/]+)\/b\/ss\// }
    ],
    'Adobe Experience Platform Launch': [
      { key: 'property', from: 'scriptSrc', regex: /assets\.adobedtm\.com\/(?:[a-f0-9]+\/)?([a-f0-9]{32})\/launch-[a-f0-9]+(?:-[a-z]+)?(?:\.min)?\.js/ },
      { key: 'environment', from: 'scriptSrc', regex: /assets\.adobedtm\.com\/[^ ]*launch-[a-f0-9]+-(development|staging)(?:\.min)?\.js/ },
      { key: 'property', from: 'js', path: '_satellite.property.id', regex: /^(PR[a-f0-9]{32})$/ }
    ],
    'Matomo Analytics': [
      { key: 'site', from: 'scripts', regex: /setSiteId['"]?\s*,\s*['"]?(\d+)/ },
      { key: 'site', from: 'requests', regex: /(?:matomo|piwik)\.php\?(?:[^#]*&)?idsite=(\d+)/ },
      { key: 'tracker', from: 'requests', regex: /^https?:\/\/([^/]+)\/[^?]*(?:matomo|piwik)\.php\?/ }
    ],
    'Matomo Tag Manager': [
      { key: 'container', from: 'scriptSrc', regex: /\/js\/container_([A-Za-z0-9]{8})\.js/ }
    ],
    'Segment': [
      { key: 'write key', from: 'scriptSrc', regex: /cdn\.segment\.com\/analytics\.js\/v1\/([A-Za-z0-9]{20,})\// },
      { key: 'write key', from: 'scripts', regex: /analytics\.load\(\s*['"]([A-Za-z0-9]{20,})['"]/ }
    ],
    'Amplitude': [
      { key: 'api key', from: 'scripts', regex: /amplitude(?:\.getInstance\(\))?\.init\(\s*['"]([a-f0-9]{32})['"]/ },
      { key: 'api key', from: 'requests', regex: /api\d?\.amplitude\.com\/[^?]*\?(?:[^#]*&)?api_key=([a-f0-9]{32})/ }
    ],
    'Mixpanel': [
      { key: 'token', from: 'scripts', regex: /mixpanel\.init\(\s*['"]([a-f0-9]{32})['"]/ }
    ],
    'Heap': [{ key: 'app', from: 'scripts', regex: /heap\.load\(\s*['"](\d{6,})['"]/ }],
    'Contentsquare': [
      { key: 'project', from: 'scriptSrc', regex: /t\.contentsquare\.net\/uxa\/([a-f0-9]+)\.js/ }
    ],
    'Plausible': [{ key: 'domain', from: 'dom', selector: 'script[data-domain][src*="plausible"]', attr: 'data-domain' }],
    'Fathom': [{ key: 'site', from: 'dom', selector: 'script[data-site][src*="usefathom"]', attr: 'data-site' }],
    'Akamai mPulse': [
      { key: 'api key', from: 'scriptSrc', regex: /c\.go-mpulse\.net\/boomerang\/([A-Z0-9-]{20,})/ },
      { key: 'api key', from: 'requests', regex: /go-mpulse\.net\/(?:boomerang|api\/config\.json)[^ ]*?(?:\/|key=)([A-Z0-9-]{20,})/ }
    ],
    'New Relic': [
      { key: 'app', from: 'scripts', regex: /applicationID\s*:\s*['"](\d+)['"]/, weak: true },
      { key: 'license', from: 'scripts', regex: /licenseKey\s*:\s*['"]([A-Za-z0-9]+)['"]/, weak: true }
    ],
    'Datadog': [
      { key: 'client token', from: 'scripts', regex: /clientToken\s*:\s*['"](pub[a-f0-9]{32})['"]/, weak: true },
      { key: 'application', from: 'scripts', regex: /applicationId\s*:\s*['"]([a-f0-9-]{36})['"]/, weak: true }
    ],
    'Sentry': [
      { key: 'dsn', from: 'scripts', regex: /dsn\s*:\s*['"](https:\/\/[a-f0-9]+@[^'"]+)['"]/ },
      { key: 'project', from: 'scriptSrc', regex: /js\.sentry-cdn\.com\/([a-f0-9]{32})\.min\.js/ }
    ],
    // ---------- Tag managers ----------
    'Commanders Act TagCommander': [
      { key: 'site', from: 'scriptSrc', regex: /cdn\.tagcommander\.com\/(\d+)\/tc_/ },
      { key: 'container', from: 'scriptSrc', regex: /cdn\.tagcommander\.com\/\d+\/tc_[A-Za-z0-9-]+_(\d+)(?:_[a-z]+)?\.js/i },
      { key: 'environment', from: 'scriptSrc', regex: /cdn\.tagcommander\.com\/\d+\/tc_[A-Za-z0-9-]+_\d+_([a-z]+)\.js/i },
      { key: 'site', from: 'requests', regex: /[?&]tc_s=(\d+)/ }
    ],
    'Tealium': [
      { key: 'account', from: 'scriptSrc', regex: /tags\.tiqcdn\.com\/utag\/([a-z0-9-]+)\/[a-z0-9-]+\/[a-z0-9-]+\/utag\.js/i },
      { key: 'profile', from: 'scriptSrc', regex: /tags\.tiqcdn\.com\/utag\/[a-z0-9-]+\/([a-z0-9-]+)\/[a-z0-9-]+\/utag\.js/i },
      { key: 'environment', from: 'scriptSrc', regex: /tags\.tiqcdn\.com\/utag\/[a-z0-9-]+\/[a-z0-9-]+\/([a-z0-9-]+)\/utag\.js/i }
    ],
    'Adobe DTM': [{ key: 'property', from: 'scriptSrc', regex: /assets\.adobedtm\.com\/([a-f0-9]{40})\/satelliteLib-([a-f0-9]{40})/ }],
    // ---------- Consent ----------
    'Didomi': [
      { key: 'api key', from: 'scriptSrc', regex: /sdk\.privacy-center\.org\/([a-f0-9-]{36})\/loader\.js/ },
      { key: 'api key', from: 'scripts', regex: /apiKey['"]?\s*[:=]\s*['"]([a-f0-9-]{36})['"]/, weak: true },
      { key: 'notice', from: 'scriptSrc', regex: /sdk\.privacy-center\.org\/[a-f0-9-]{36}\/loader\.js\?(?:[^#]*&)?target=([^&]+)/ },
      { key: 'notice', from: 'scripts', regex: /noticeId['"]?\s*[:=]\s*['"]([A-Za-z0-9]{6,})['"]/, weak: true }
    ],
    'OneTrust': [
      { key: 'domain script', from: 'dom', selector: 'script[data-domain-script]', attr: 'data-domain-script' },
      { key: 'domain script', from: 'scriptSrc', regex: /cdn\.cookielaw\.org\/consent\/([a-f0-9-]{36}(?:-test)?)\// }
    ],
    'Cookiebot': [
      { key: 'cbid', from: 'dom', selector: 'script[data-cbid]', attr: 'data-cbid' },
      { key: 'cbid', from: 'scriptSrc', regex: /consent\.cookiebot\.(?:com|eu)\/uc\.js\?(?:[^#]*&)?cbid=([a-f0-9-]{36})/ }
    ],
    'Axeptio': [
      { key: 'client', from: 'scripts', regex: /axeptioSettings\s*=\s*\{[^}]*?clientId\s*:\s*['"]([a-f0-9]{24})['"]/ },
      { key: 'cookies version', from: 'scripts', regex: /cookiesVersion\s*:\s*['"]([^'"]+)['"]/, weak: true }
    ],
    'Usercentrics': [
      { key: 'settings', from: 'dom', selector: 'script[data-settings-id]', attr: 'data-settings-id' }
    ],
    'Commanders Act TrustCommander': [
      { key: 'site', from: 'scriptSrc', regex: /cdn\.trustcommander\.net\/privacy\/(\d+)\// },
      { key: 'privacy', from: 'scriptSrc', regex: /cdn\.trustcommander\.net\/privacy\/\d+\/privacy_v?(\d+)/ }
    ],
    'Quantcast Choice': [{ key: 'account', from: 'scripts', regex: /quantcast\.mgr\.consensu\.org\/[^'"]*\/([a-zA-Z0-9]{16})\//i }],
    'CookieYes': [{ key: 'site', from: 'scriptSrc', regex: /cdn-cookieyes\.com\/client_data\/([a-f0-9]{24})\// }],
    // ---------- CMS / e-commerce ----------
    'Shopify': [
      { key: 'shop', from: 'js', path: 'Shopify.shop', regex: /^([a-z0-9-]+\.myshopify\.com)$/i },
      { key: 'shop id', from: 'headers', name: 'x-shopid', regex: /^(\d+)$/ },
      { key: 'shop id', from: 'js', path: 'ShopifyAnalytics.meta.page.shopId', regex: /^(\d+)$/ },
      { key: 'theme', from: 'js', path: 'Shopify.theme.name', regex: /^(.+)$/ },
      { key: 'theme id', from: 'js', path: 'Shopify.theme.id', regex: /^(\d+)$/ },
      { key: 'theme role', from: 'js', path: 'Shopify.theme.role', regex: /^(.+)$/ },
      { key: 'locale', from: 'js', path: 'Shopify.locale', regex: /^([a-z]{2}(?:-[A-Z]{2})?)$/ },
      { key: 'currency', from: 'js', path: 'Shopify.currency.active', regex: /^([A-Z]{3})$/ }
    ],
    'WordPress': [
      { key: 'theme', from: 'html', regex: /\/wp-content\/themes\/([a-z0-9_.-]+)\//gi },
      { key: 'plugin', from: 'html', regex: /\/wp-content\/plugins\/([a-z0-9_.-]+)\//gi, max: 25 }
    ],
    'WooCommerce': [
      { key: 'version', from: 'html', regex: /\/wp-content\/plugins\/woocommerce\/[^"']*\?ver=([\d.]+)/i },
      { key: 'version', from: 'meta', name: 'generator', regex: /WooCommerce ([\d.]+)/i }
    ],
    'Salesforce Commerce Cloud': [
      { key: 'site', from: 'html', regex: /\/on\/demandware\.store\/Sites-([A-Za-z0-9_-]+)-Site\//g },
      { key: 'site', from: 'requests', regex: /\/on\/demandware\.store\/Sites-([A-Za-z0-9_-]+)-Site\//g },
      { key: 'locale', from: 'html', regex: /\/on\/demandware\.store\/Sites-[A-Za-z0-9_-]+-Site\/([a-z]{2}_[A-Z]{2})\//g },
      { key: 'static', from: 'html', regex: /\/on\/demandware\.static\/-\/Sites-([A-Za-z0-9_-]+)\//g }
    ],
    'Magento': [
      { key: 'deploy version', from: 'html', regex: /\/static\/version(\d{8,})\//g, weak: true },
      { key: 'store', from: 'scripts', regex: /["']store(?:Code)?["']\s*:\s*["']([a-z0-9_]+)["']/i, weak: true }
    ],
    'PrestaShop': [
      { key: 'shop', from: 'js', path: 'prestashop.static_token', regex: /^([a-f0-9]{32})$/ },
      { key: 'theme', from: 'html', regex: /\/themes\/([a-z0-9_-]+)\/assets\//gi, weak: true }
    ],
    'Webflow': [
      { key: 'site', from: 'dom', selector: 'html[data-wf-site]', attr: 'data-wf-site' },
      { key: 'page', from: 'dom', selector: 'html[data-wf-page]', attr: 'data-wf-page' }
    ],
    'Wix': [
      { key: 'site', from: 'js', path: 'wixBiSession.msId', regex: /^([a-f0-9-]{36})$/ },
      { key: 'meta site', from: 'html', regex: /metaSiteId["']?\s*[:=]\s*["']([a-f0-9-]{36})/, weak: true }
    ],
    'Squarespace': [
      { key: 'site', from: 'js', path: 'Static.SQUARESPACE_CONTEXT.website.id', regex: /^([a-f0-9]{24})$/ },
      { key: 'template', from: 'js', path: 'Static.SQUARESPACE_CONTEXT.templateId', regex: /^([a-f0-9]{24})$/ }
    ],
    'HubSpot': [
      { key: 'portal', from: 'scriptSrc', regex: /js(?:-eu1)?\.hs-scripts\.com\/(\d+)\.js/ },
      { key: 'portal', from: 'scriptSrc', regex: /js\.hsforms\.net\/forms\/[^?]*\?(?:[^#]*&)?portalId=(\d+)/ },
      { key: 'portal', from: 'scripts', regex: /portalId\s*:\s*['"]?(\d{5,})['"]?/, weak: true }
    ],
    'Drupal': [{ key: 'version', from: 'meta', name: 'generator', regex: /Drupal ([\d.]+)/i }],
    'Joomla': [{ key: 'version', from: 'meta', name: 'generator', regex: /Joomla!?\s*-?\s*([\d.]+)/i }],
    'Ghost': [{ key: 'version', from: 'meta', name: 'generator', regex: /Ghost ([\d.]+)/i }],
    // ---------- Marketing / CRM / widgets ----------
    'Klaviyo': [
      { key: 'company', from: 'scriptSrc', regex: /static\.klaviyo\.com\/onsite\/js\/(?:klaviyo\.js\?(?:[^#]*&)?company_id=|)([A-Za-z0-9]{6})(?:\/|&|$)/ },
      { key: 'company', from: 'scriptSrc', regex: /klaviyo\.js\?(?:[^#]*&)?company_id=([A-Za-z0-9]{6})/ }
    ],
    'Batch': [
      { key: 'api key', from: 'requests', regex: /ws\.batch\.com\/web\/[^/]+\/(?:ev|atc|ats)\/([A-Z0-9]{32})/ },
      { key: 'api key', from: 'requests', regex: /safari-ws\.batch\.com\/([A-Z0-9]{32})\// },
      { key: 'api key', from: 'scripts', regex: /apiKey\s*:\s*['"]([A-Z0-9]{32})['"]/, weak: true }
    ],
    'Wunderkind': [
      { key: 'website', from: 'scriptSrc', regex: /tag\.(?:wknd\.ai|bounceexchange\.com)\/(\d+)\/i\.js/ },
      { key: 'website', from: 'requests', regex: /bounceexchange\.com\/cache\/(\d+)\// }
    ],
    'Intercom': [
      { key: 'app', from: 'scripts', regex: /app_id\s*:\s*['"]([a-z0-9]{6,})['"]/, weak: true },
      { key: 'app', from: 'scriptSrc', regex: /widget\.intercom\.io\/widget\/([a-z0-9]{6,})/ }
    ],
    'Zendesk': [
      { key: 'key', from: 'scriptSrc', regex: /static\.zdassets\.com\/ekr\/snippet\.js\?(?:[^#]*&)?key=([a-f0-9-]{36})/ },
      { key: 'zopim', from: 'scriptSrc', regex: /v2\.zopim\.com\/\?([a-zA-Z0-9]{20,})/ }
    ],
    'Crisp Live Chat': [{ key: 'website', from: 'js', path: 'CRISP_WEBSITE_ID', regex: /^([a-f0-9-]{36})$/ }],
    'Drift': [{ key: 'account', from: 'scripts', regex: /drift\.load\(\s*['"]([a-z0-9]{8,})['"]/ }],
    'Tawk.to': [{ key: 'property', from: 'scriptSrc', regex: /embed\.tawk\.to\/([a-f0-9]{24})\/([a-z0-9]+)/ }],
    'MailChimp': [{ key: 'user', from: 'scriptSrc', regex: /chimpstatic\.com\/mcjs-connected\/js\/users\/([a-f0-9]{32})\/([a-f0-9]{10})\.js/ }],
    'Bazaarvoice Reviews': [
      { key: 'client', from: 'scriptSrc', regex: /apps\.bazaarvoice\.com\/deployments\/([a-z0-9_-]+)\/([a-z0-9_-]+)\/(production|staging)\/([a-z_-]+)\/bv\.js/i }
    ],
    'Trustpilot': [{ key: 'business unit', from: 'dom', selector: '.trustpilot-widget[data-businessunit-id]', attr: 'data-businessunit-id' }],
    'Yotpo Reviews': [{ key: 'app key', from: 'scriptSrc', regex: /staticw2\.yotpo\.com\/([A-Za-z0-9]{20,})\/widget\.js/ }],
    'AB Tasty': [{ key: 'account', from: 'scriptSrc', regex: /try\.abtasty\.com\/([a-f0-9]{32})\.js/ }],
    'Kameleoon': [{ key: 'site code', from: 'scriptSrc', regex: /([a-z0-9]+)\.kameleoon\.(?:eu|io|com)\/kameleoon\.js/i }],
    'Optimizely': [{ key: 'project', from: 'scriptSrc', regex: /cdn(?:-pci)?\.optimizely\.com\/js\/(\d+)\.js/ }],
    'VWO': [{ key: 'account', from: 'scriptSrc', regex: /dev\.visualwebsiteoptimizer\.com\/j\.php\?(?:[^#]*&)?a=(\d+)/ }],
    'Dynamic Yield': [{ key: 'section', from: 'scriptSrc', regex: /cdn(?:-eu)?\.dynamicyield\.com\/api\/(\d+)\/api_/ }],
    'Algolia': [{ key: 'app', from: 'scripts', regex: /algoliasearch\(\s*['"]([A-Z0-9]{10})['"]/ }],
    'Stripe': [{ key: 'publishable key', from: 'scripts', regex: /(pk_(?:live|test)_[A-Za-z0-9]{20,})/ }],
    'PayPal': [{ key: 'client', from: 'scriptSrc', regex: /paypal\.com\/sdk\/js\?(?:[^#]*&)?client-id=([A-Za-z0-9_-]{20,})/ }],
    'Google Font API': [{ key: 'family', from: 'links', regex: /[?&]family=([^&:]+)/g, max: 8, decode: true, filter: /fonts\.googleapis\.com\/css/, weak: true }],
    'Font Awesome': [{ key: 'kit', from: 'scriptSrc', regex: /kit\.fontawesome\.com\/([a-f0-9]{10})\.js/ }],
  };

  // Extra collection the rules need on top of what the fingerprints ask for.
  function collectionPlan() {
    const js = new Set(), jsKeys = new Set(), dom = new Set();
    for (const rules of Object.values(RULES)) {
      for (const r of rules) {
        if (r.from === 'js') js.add(r.path);
        if (r.from === 'jsKeys') jsKeys.add(r.path);
        if (r.from === 'dom') dom.add(r.selector);
      }
    }
    return { js: [...js], jsKeys: [...jsKeys], dom: [...dom] };
  }

  function valuesFor(rule, page) {
    switch (rule.from) {
      case 'scriptSrc': return page.scriptSrc || [];
      case 'requests': return page.xhr || [];
      case 'scripts': return page.scripts || [];
      case 'html': return page.html ? [page.html] : [];
      case 'links': return (page.links || []).map((l) => (typeof l === 'string' ? l : l.href)).filter(Boolean);
      case 'url': return page.url ? [page.url] : [];
      case 'js': { const v = page.js && page.js[rule.path]; return v === undefined || v === null ? [] : [String(v)]; }
      case 'jsKeys': return (page.jsKeys && page.jsKeys[rule.path]) || [];
      case 'dom': { const nodes = page.dom && page.dom[rule.selector]; return nodes ? nodes.map(n => n.attributes && n.attributes[rule.attr]).filter(Boolean) : []; }
      case 'meta': { const m = lower(page.meta || {}); return m[rule.name.toLowerCase()] || []; }
      case 'headers': { const h = lower(page.headers || {}); return h[rule.name.toLowerCase()] || []; }
      case 'cookies': return Object.keys(page.cookies || {});
      default: return [];
    }
  }
  function lower(o) { const r = {}; for (const [k, v] of Object.entries(o)) r[k.toLowerCase()] = Array.isArray(v) ? v : [v]; return r; }

  function applyRule(rule, page) {
    const out = [];
    const seen = new Set();
    const max = rule.max || 12;
    for (const value of valuesFor(rule, page)) {
      if (typeof value !== 'string') continue;
      if (rule.filter && !rule.filter.test(value)) continue;
      if (!rule.regex) { push(value); continue; }
      const rx = rule.regex.global ? new RegExp(rule.regex.source, rule.regex.flags) : rule.regex;
      let m;
      if (rx.global) { while ((m = rx.exec(value)) && out.length < max) push(join(m)); }
      else if ((m = rx.exec(value))) push(join(m));
      if (out.length >= max) break;
    }
    function join(m) { const parts = m.slice(1).filter(x => x !== undefined && x !== ''); return parts.join(' · '); }
    function push(v) {
      if (rule.decode) { try { v = decodeURIComponent(v.replace(/\+/g, ' ')); } catch (e) { /* keep raw */ } }
      v = v.trim();
      if (rule.prefix && v && !v.toUpperCase().startsWith(rule.prefix.toUpperCase())) v = rule.prefix + v;
      if (!v || seen.has(v)) return;
      seen.add(v);
      out.push({ key: rule.key, value: v, source: rule.from === 'requests' ? 'xhr' : rule.from, weak: !!rule.weak });
    }
    return out;
  }

  /**
   * Returns { [techName]: [ { key, value, source, weak } ] } for every rule
   * that matched. Pass the set of technology names the engine detected:
   * weak-only matches for an undetected technology are dropped.
   */
  function extract(page, detected) {
    const result = {};
    for (const [name, rules] of Object.entries(RULES)) {
      const ids = [];
      const seen = new Set();
      for (const rule of rules) {
        for (const id of applyRule(rule, page)) {
          const sig = id.key + '=' + id.value;
          if (seen.has(sig)) continue;
          seen.add(sig);
          ids.push(id);
        }
      }
      if (!ids.length) continue;
      if (detected && !detected.has(name) && ids.every((i) => i.weak)) continue;
      result[name] = ids;
    }
    return result;
  }

  const api = { RULES, collectionPlan, extract, applyRule };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.TechIds = api;
})(typeof self !== 'undefined' ? self : globalThis);
